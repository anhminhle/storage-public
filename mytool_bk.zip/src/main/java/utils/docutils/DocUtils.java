package utils.docutils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.usermodel.CharacterRun;
import org.apache.poi.hwpf.usermodel.Paragraph;
import org.apache.poi.hwpf.usermodel.Range;
import org.apache.poi.hwpf.usermodel.Section;
import org.apache.poi.xwpf.usermodel.XWPFDocument;



public class DocUtils {

    private static Logger logger = LogManager.getLogger(DocUtils.class);

    public static HWPFDocument replaceText(HWPFDocument doc, String findText, String replaceText) {
        Range r1 = doc.getRange();

        for (int i = 0; i < r1.numSections(); ++i) {
            Section s = r1.getSection(i);
            for (int x = 0; x < s.numParagraphs(); x++) {
                Paragraph p = s.getParagraph(x);
                for (int z = 0; z < p.numCharacterRuns(); z++) {
                    CharacterRun run = p.getCharacterRun(z);
                    String text = run.text();
                 //   System.out.println(text);
                    if (text.contains(findText)) {
                        System.out.println(findText);
                        run.replaceText(findText, replaceText);
                    }
                }
            }
        }
        return doc;
    }

    public static void saveFile(String filePath, HWPFDocument doc) throws FileNotFoundException, IOException {
        FileOutputStream out = null;
        try {
            File file = new File(filePath);
            file.deleteOnExit();
            out = new FileOutputStream(filePath);
            doc.write(out);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);

        } finally {
            if (out != null) {
                out.close();
            }
        }
    }


    public static void replace(HWPFDocument doc, Map<String, String> mapContent) {
        Map<String, String> treeMap = new TreeMap<>(
            new Comparator<String>() {
                @Override
                public int compare(String s1, String s2) {
                    if (s1.length() > s2.length()) {
                        return -1;
                    } else if (s1.length() < s2.length()) {
                        return 1;
                    } else {
                        return s1.compareTo(s2);
                    }
                }
        });
        for (Map.Entry<String, String> entry : mapContent.entrySet()) {
            String key = entry.getKey();                        
            String value = entry.getValue();
            treeMap.put(key, value);
        }
        for (Map.Entry<String, String> entry : treeMap.entrySet()) {
            String key = entry.getKey();                        
            String value = entry.getValue();
                doc.getRange().replaceText(key, value);
            }
        }
    
    
     public static void saveFileDocx(String filePath, XWPFDocument doc) throws FileNotFoundException, IOException {
        FileOutputStream out = null;
        try {
            File file = new File(filePath);
            file.deleteOnExit();
            out = new FileOutputStream(filePath);
            doc.write(out);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);

        } finally {
            if (out != null) {
                out.close();
            }
        }
    }
      
      
       public static void replaceDocx(XWPFDocument doc, Map<String, String> mapContent) {
        Iterator<Map.Entry<String, String>> iterator = mapContent.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            String key = entry.getKey();
//            if(key.equals("933@plan_mon@")){//933@plan_mon@
//                System.out.println("aloha aloha " +entry.getValue());
//            }
                
            String value = entry.getValue();
            if (value == null) {
                value = "";
            }
            
            TextReplacer replacer = new TextReplacer();
            replacer.replaceInText(doc, key, value);
            replacer.replaceInTable(doc, key, value);
        }
    }

    public static void main(String[] args) {
        //readFile();
    }

}
