/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author minhla2
 */
public class DBProcessUtils {
    public static Connection getConnection(String driver, String connStr, String user, String pass) throws ClassNotFoundException, SQLException {
        Class.forName(driver);
        DriverManager.setLoginTimeout(30);
        Connection con = DriverManager.getConnection(connStr, user, pass);
        return con;
    }
}
