/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package utils.mocha;

/**
 *
 * @author minhla2
 */
public class MochaConstants {
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String TYPE = "type";
    public static final String FROM = "from";
    public static final String TO = "to";
    public static final String DATA = "data";
    public static final String CONTENT = "content";
    public static final String FILES = "files";
    public static final String MOCHA_URL = "http://10.60.139.240:7000/";
    public static final String SEND_MESS_MOCHA_URL = "privateapi/vsds/sendTextMessage";
    public static final String SEND_IMG_MOCHA_URL = "privateapi/vsds/sendImageMessage";
    public static final String UPLOAD_IMG_MOCHA_URL = "privateapi/vsds/upload";
    public static final String MOCHA_VTT_USERNAME="VTT";
    public static final String MOCHA_VTT_PASSWORD="VTT$#@rfv2022";
    public static final String MOCHA_VTT_OA="VTT_SoLieu";
    public static final String TYPE0 = "0";
    public static final String TYPE1 = "1";
    public static final String TYPE2 = "2";
}
