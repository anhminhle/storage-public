/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils.mocha;

import java.util.ArrayList;

/**
 *
 * @author binhvd7
 */
public class MochaImgObj {
    
    public ArrayList<ImageMocha> images;

    public MochaImgObj() {
    }

    public MochaImgObj( ArrayList<ImageMocha> images) {

        this.images = images;
    }
    
    
    

    public ArrayList<ImageMocha> getImages() {
        return images;
    }

    public void setImages(ArrayList<ImageMocha> images) {
        this.images = images;
    }
    
    
}

////class Image{
////    public String url;
////    public String ratio;
////
////    public Image() {
////    }
////
////    public Image(String url, String ratio) {
////        this.url = url;
////        this.ratio = ratio;
////    }
////
////    
////    public String getUrl() {
////        return url;
////    }
////
////    public void setUrl(String url) {
////        this.url = url;
////    }
////
////    public String getRatio() {
////        return ratio;
////    }
////
////    public void setRatio(String ratio) {
////        this.ratio = ratio;
////    }
//    