/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils.mocha;

/**
 *
 * @author binhvd7
 */
public class ImageMocha {
    private String url;
    private String ratio;

    public ImageMocha() {
    }

    public ImageMocha(String url, String ratio) {
        this.url = url;
        this.ratio = ratio;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getRatio() {
        return ratio;
    }

    public void setRatio(String ratio) {
        this.ratio = ratio;
    }
    
    
}
