/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package utils.mocha;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import com.google.gson.Gson;

import okhttp3.ConnectionPool;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 *
 * @author minhla2
 */
public class MochaUtils {
    
    public static Response uploadIMGFile(String USERNAME, String PASSWORD, File file) {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.MINUTES)
                .writeTimeout(10, TimeUnit.MINUTES)
                .readTimeout(10, TimeUnit.MINUTES)
                .connectionPool(new ConnectionPool(10, 1, TimeUnit.HOURS))
                .build();
        Request request = null;
        Response response = null;

        try {
            String s1 = "";
            RequestBody formBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart(MochaConstants.FILES, file.getName(),
                            RequestBody.create(MediaType.parse("image/png"), file))
                    .addFormDataPart(MochaConstants.USERNAME, USERNAME)
                    .addFormDataPart(MochaConstants.PASSWORD, PASSWORD)
                    .build();

            request = new Request.Builder()
                    .url(MochaConstants.MOCHA_URL + MochaConstants.UPLOAD_IMG_MOCHA_URL)
                    .post(formBody)
                    .addHeader("content-type", "image/png")
                    .build();

            response = client.newCall(request).execute();

            return response;

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
        
    public static Response sendIMGMocha(String USERNAME, String PASSWORD, String fromTel, String toTel, String data, String type) throws IOException {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.MINUTES)
                .writeTimeout(10, TimeUnit.MINUTES)
                .readTimeout(10, TimeUnit.MINUTES)
                .connectionPool(new ConnectionPool(10, 1, TimeUnit.HOURS))
                .build();
        Request request = null;
        okhttp3.Response response = null;
        try {

            ArrayList<ImageMocha> l = new ArrayList<>();
            Gson g = new Gson();
            ImageMocha o = new ImageMocha(data, "1");
            l.add(o);
            MochaImgObj obj = new MochaImgObj(l);
            String send = g.toJson(obj);

            RequestBody form = new FormBody.Builder()
                    .add(MochaConstants.USERNAME, USERNAME)
                    .add(MochaConstants.PASSWORD, PASSWORD)
                    .add(MochaConstants.TYPE, type)
                    .add(MochaConstants.FROM, fromTel)
                    .add(MochaConstants.TO, toTel)
                    .add(MochaConstants.DATA, data)
                    .build();
            request = new Request.Builder()
                    .url(MochaConstants.MOCHA_URL + MochaConstants.SEND_IMG_MOCHA_URL)
                    .post(form)
                    .build();
            response = client.newCall(request).execute();
        } catch (IOException ex) {
            throw ex;
        }
        return response;
    }
    
    public static Response sendTextMocha(String USERNAME, String PASSWORD, String fromTel, String toTel, String content, String type) throws IOException {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.MINUTES)
                .writeTimeout(10, TimeUnit.MINUTES)
                .readTimeout(10, TimeUnit.MINUTES)
                .connectionPool(new ConnectionPool(10, 1, TimeUnit.HOURS))
                .build();
        Request request = null;
        okhttp3.Response response = null;
        try {
            RequestBody form = new FormBody.Builder()
                    .add(MochaConstants.USERNAME, USERNAME)
                    .add(MochaConstants.PASSWORD, PASSWORD)
                    .add(MochaConstants.TYPE, type)
                    .add(MochaConstants.FROM, fromTel)
                    .add(MochaConstants.TO, toTel)
                    .add(MochaConstants.CONTENT, content)
                    .build();
            request = new Request.Builder()
                    .url(MochaConstants.MOCHA_URL + MochaConstants.SEND_MESS_MOCHA_URL)
                    .post(form)
                    .build();
            response = client.newCall(request).execute();
        } catch (IOException ex) {
            throw ex;
        }
        return response;
    }
}
