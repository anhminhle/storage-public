/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package utils;

import java.awt.Desktop;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author minhla2
 */
public class GeneralUtils {

    public static void appendToFile(String text, String filePathOut, Boolean isAppend) throws IOException{
        try(
            FileWriter writer = new FileWriter(filePathOut, isAppend);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
        ){
            if (text != null) bufferedWriter.write(text);
        }
    }

    public static void openFileDesktop(String filePath) throws IOException{
                //text file, should be opening in default text editor
        File file = new File(filePath);

        //first check if Desktop is supported by Platform or not
        if(!Desktop.isDesktopSupported()){
            System.out.println("Desktop is not supported");
            return;
        }

        Desktop desktop = Desktop.getDesktop();
        if(file.exists()) desktop.open(file);
    }

    public static String standardPhoneNumber(String isdn) {
        if (isdn == null) {
            return "";
        }
        if (isdn.startsWith("84")) {
            return isdn;
        } else if (isdn.startsWith("0")) {
            return "84" + isdn.substring(1);
        } else {
            return "84" + isdn;
        }
    }

    public static void createFileIfNotExists(String filePathString) throws IOException{
        Path filePath = Paths.get(filePathString);
        if (!Files.exists(filePath))
            Files.createFile(filePath);
    }

    public static void deleteFileIfExists(String filePathString) throws IOException{
        Path filePath = Paths.get(filePathString);
        Files.deleteIfExists(filePath);
    }

    // Example: "abcdef" "cd" 2 -> return = "abcdcdef"
    public static String insertStringBeforeIndex(String orgStr, String insertStr, Integer index){
        return orgStr.substring(0, index + 1) + insertStr+ orgStr.substring(index + 1);
    }

    public static String findNextSubStrStartsAndEndsWith(String str, int startPos, String startsWith, String endsWith, List<Integer> resultPos) {
        String result = null;
        int begin = StringUtils.indexOfIgnoreCase(str, startsWith, startPos);
        if (begin == -1) return null;
        int end = StringUtils.indexOfIgnoreCase(str, endsWith, begin + startsWith.length());
        if (end == -1) return null;
        resultPos.add(begin);
        resultPos.add(end + endsWith.length());
        result = StringUtils.substring(str, begin, end + endsWith.length());
        return result;
    }

    public static void dumpStringsToFile(List<String> strings, String filePath) throws IOException{
        dumpStringsToFile(strings, filePath, false);
    }
    public static void dumpStringsToFile(String string, String filePath, Boolean isAppend) throws IOException{
        dumpStringsToFile(Arrays.asList(string), filePath, isAppend);
    }
    //Also create file if not exists (not sure about folder). UTF-8.
    public static void dumpStringsToFile(List<String> strings, String filePath, Boolean isAppend) throws IOException{
        GeneralUtils.createFileIfNotExists(filePath);
        try(
            // FileWriter writer = new FileWriter(filePath, isAppend);
            // BufferedWriter bufferedWriter = new BufferedWriter(writer);
            BufferedWriter bufferedWriter
                = Files.newBufferedWriter(Paths.get(filePath),
                    StandardCharsets.UTF_8,StandardOpenOption.CREATE,
                    StandardOpenOption.WRITE,
                    isAppend ? StandardOpenOption.APPEND : StandardOpenOption.TRUNCATE_EXISTING);
                )
        {
            for (int i=0;i<strings.size();i++){
                String str = strings.get(i);
                bufferedWriter.write(str);
                if (i+1<strings.size()) bufferedWriter.newLine();
            }
        }
    }

    public static Boolean startsWithAnyIgnoreCase(String str, List<String> startsWith){
        for (String start : startsWith){
            if (StringUtils.startsWithIgnoreCase(str, start)) return true;
        }
        return false;
    }

    public static String deleteStartsWithAnyIgnoreCase(String str, List<String> startsWith){
        for (String start : startsWith){
            if (StringUtils.startsWithIgnoreCase(str, start))
                return StringUtils.replaceIgnoreCase(str,start, "");
        }
        return str;
    }

    public static List<String> extractAllHyperLink(String htmlContent){
        String hyperLinkBegin = "<a href=";
        String hyperLinkEnd = "</a>";
        String hyperLink = "";
        List<String> hyperLinks = new ArrayList<>();
        int startPos = 0;
        while (hyperLink != null){
            List<Integer> resultPos = new ArrayList<>();
            hyperLink = GeneralUtils.findNextSubStrStartsAndEndsWith(htmlContent, startPos, hyperLinkBegin, hyperLinkEnd, resultPos);
            if (hyperLink != null)
            {
                startPos = resultPos.get(1);
                hyperLinks.add(hyperLink);
            }
        }
        return hyperLinks;
    }
    //extract All HyperLink from an HTML file : startsWith <a href= ends with </a>
    public static List<String> extractAllHyperLinkFromFile(String filePathIn) throws IOException{
        String textIn = new String(Files.readAllBytes(Paths.get(filePathIn)), "UTF-8");
        return extractAllHyperLink(textIn);
    }

}
