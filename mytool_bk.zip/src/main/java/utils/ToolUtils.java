package utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ToolUtils {
    public static void prepareToolDirs(String[] folders, String[] filesCreate, String[] filesRecreate) throws IOException{
        for (String path : folders) Files.createDirectories(Paths.get(path));
        for (String path : filesCreate) GeneralUtils.createFileIfNotExists(path);
        for (String path : filesRecreate){
            GeneralUtils.deleteFileIfExists(path);
            GeneralUtils.createFileIfNotExists(path);
        }
    }
}
