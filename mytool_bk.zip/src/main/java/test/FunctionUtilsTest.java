/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import main.tools.tool10.Tool10;
import main.tools.tool10.Tool10Utils;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
public class FunctionUtilsTest {
    //prdId format: yyyyMMdd
    static String urlBIMonitor = "http://10.60.129.8:8088/viettel-bi-monitor/?ticket=ST-6654-uIfWkLMdcKor2ncKo0N5-cas";
    static String FOLDER_PATH_OUT = "test/";
    public static void main(){
    }
}
