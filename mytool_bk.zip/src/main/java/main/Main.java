/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import main.tools.Tool1;
import main.tools.Tool2;
import main.tools.Tool3;
import main.tools.Tool4;
import main.tools.Tool5;
import main.tools.Tool6;
import main.tools.Tool7;
import main.tools.tool10.Tool10;
import main.tools.tool11.Tool11;
import main.tools.tool12.Tool12;
import main.tools.tool13.Tool13;
import main.tools.tool14.Tool14;
import main.tools.tool15.Tool15;
import main.tools.tool16.Tool16;
import main.tools.tool17.Tool17;
import main.tools.tool18.Tool18;
import main.tools.tool9.Tool9;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
public class Main {

    private static final Logger logger = Logger.getLogger(Main.class);
    /**
     * @param args the command line arguments
     */

    public static void init(){
        System.out.println("Start!");
    }
    public static void test(){
    }

    public static void main(String[] args) throws ParseException, UnsupportedEncodingException{
        init();
        test();
//        if (true) return;
        logger.info("Start!");

        Tool1 tool1 = new Tool1();
        Tool2 tool2 = new Tool2();
        Tool3 tool3 = new Tool3();
        Tool4 tool4 = new Tool4();
        Tool5 tool5 = null; //Also off birt dependencies
        Tool6 tool6 = new Tool6();
        Tool7 tool7 = new Tool7();
        Tool9 tool9 = new Tool9();
        Tool10 tool10 = new Tool10();
        Tool11 tool11 = new Tool11();
        Tool12 tool12 = new Tool12();
        Tool13 tool13 = new Tool13();
        Tool14 tool14 = new Tool14();
        Tool15 tool15 = new Tool15();
        Tool16 tool16 = new Tool16();
        Tool17 tool17 = new Tool17();
        Tool18 tool18 = new Tool18();
//        Tool8 tool8 = new Tool8();

        try(Scanner console = new Scanner(System.in)){
            String x;
            do{
                System.out.println("Type a number (0 to exit, 01 to open tool folder, 02 for docs ): ");
                x = console.nextLine();
                // x = 0;
                try{
                    switch (x){
                    case "02":
                        String docsDir = "tools/Instructions.txt";
                        String docs = new String(Files.readAllBytes(Paths.get(docsDir)), "UTF-8");
                        System.out.println(docs);
                        break;
                    case "01":
                        GeneralUtils.openFileDesktop("tools");
                        break;
                    case "1":
                        tool1.main();
                        break;
                    case "2":
                        tool2.main();
                        break;
                    case "3":
                        tool3.main();
                        break;
                    case "4":
                        tool4.main();
                        break;
                    case "5":
                        // if (tool5 == null) tool5 = new Tool5();
                        // tool5.main();
                        System.out.println("Tool is off");
                        break;
                    case "6":
                        tool6.main();
                        break;
                    case "7":
                        tool7.main();
                        break;
                    case "8":
    //                    tool8.main();
                        System.out.println("Tool is off");
                        break;
                    case "9":
                        tool9.main();
                        break;
                    case "10":
                        tool10.main();
                        break;
                    case "11":
                        tool11.main();
                        break;
                    case "12":
                        tool12.main();
                        break;
                    case "13":
                        tool13.main();
                        break;
                    case "14":
                        tool14.main();
                        break;
                    case "15":
                        tool15.main();
                        break;
                    case "16":
                        tool16.main();
                        break;
                    case "17":
                        tool17.main();
                        break;
                    case "18":
                        tool18.main();
                        break;
                    }
                }catch(NullPointerException | ClassNotFoundException | SQLException | IOException | ParseException ex){
                    logger.error("Error: ", ex);
                } catch (Exception ex) {
                    logger.error("Error: ", ex);;
                }
            }while (!"0".equals(x));
        }

    }
}
