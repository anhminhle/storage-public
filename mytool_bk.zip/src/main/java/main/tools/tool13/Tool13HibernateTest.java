package main.tools.tool13;

import com.viettel.eafs.aop.HibernateTransactionManagerAspect;
import com.viettel.eafs.dataaccess.aware.HibernateAware;
// import com.viettel.eafs.dataaccess.helper.HibernateHelper;
import com.viettel.eafs.dataaccess.transaction.manager.AspectJHibernateTransactionManager;

public class Tool13HibernateTest implements HibernateAware {

    // private static Logger logger = Logger.getLogger(Tool13HibernateTest.class);
    Tool13HibernateConnector hiberConn;
    AspectJHibernateTransactionManager hiberTM;
    HibernateTransactionManagerAspect hiberAspect;
//    Tool13C3P0DataSourceConnector c3p0Conn;

    // private HibernateHelper getDBHelper() {
    //     return hh;
    // }

    public void init(String inFolder) throws Throwable {
        hiberConn = new Tool13HibernateConnector();
        hiberConn.setFactoryConfigFilePath(inFolder + "hibernateFactories.xml");
        hiberConn.tool13ReadConfiguration();
//        hiberConn.tool13InitDataSource();
        
//        hiberConn.startup();

//        hiberTM = new AspectJHibernateTransactionManager();
//        hiberTM.setConnector(hiberConn);
//        hiberTM.setPropagation("append");
//
//        hiberAspect = new HibernateTransactionManagerAspect();
//        hiberAspect.setTransactionManager(hiberTM);

//        c3p0Conn = new Tool13C3P0DataSourceConnector();
//        c3p0Conn.setDatasourceConfigFilePath(inFolder + "c3p0Datasources.xml");
//        c3p0Conn.tool13ReadConfiguration();
//        c3p0Conn.startup();
    }

    public Tool13HibernateTest(String inFolder) throws Throwable {
        init(inFolder);
    }
    
    public void main(String[] args){

    }
}
