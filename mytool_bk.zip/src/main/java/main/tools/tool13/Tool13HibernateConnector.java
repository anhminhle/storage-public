/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.tools.tool13;

/**
 *
 * @author minhla2
 */
public class Tool13HibernateConnector extends com.viettel.eafs.dataaccess.connector.HibernateConnector{
    
    // private HashMap<String, HibernateSessionFactoryConfig> factoryConfigMap = new HashMap<String, HibernateSessionFactoryConfig>();
    // private HashMap<String, SessionFactory> factoryMap = new HashMap<String, SessionFactory>();
    
    public void tool13ReadConfiguration() throws Throwable{
        Tool13Interpreter xmlInterpreter = new Tool13Interpreter(this);
        xmlInterpreter.tool13Interprete(super.getFactoryConfigFilePath());
    }
    
//    public void tool13ApplyConfiguration(HashMap<String, HibernateSessionFactoryConfig> datasourceConfigMap, String defaultDataSourceName){
//        this.factoryConfigMap = datasourceConfigMap;
//        setDefSesName(defaultDataSourceName);
//    }
}

