/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.tools.tool13;

import constants.Constants;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import org.apache.log4j.Logger;
import utils.GeneralUtils;
import utils.ViettelEncryptDecryptUtil;

/**
 *
 * @author minhla2
 */
public class Tool13 {
    private static final Logger logger = Logger.getLogger(Tool13.class);

    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool13/";
    final String CONFIG_DIR = TOOL_DIR + "configTool13.properties";
    final String FOLDER_IN_DIR = TOOL_DIR + "In/";
    final String FOLDER_OUT_DIR = TOOL_DIR + "Out/";
    final String FILE_IN_DIR = FOLDER_IN_DIR + "in.txt";
    List<String> fileInPathLists;

    public void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(FOLDER_IN_DIR));
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        GeneralUtils.createFileIfNotExists(CONFIG_DIR);
        GeneralUtils.createFileIfNotExists(FILE_IN_DIR);
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            String fileInPathText = new String(Files.readAllBytes(Paths.get(FILE_IN_DIR)), "UTF-8");
            fileInPathLists = Arrays.asList(fileInPathText.replaceAll("\r", "").split("\n"));
        }
    }

    public void main() throws IOException{
        init();
        logger.info("Tool 13 Start!");
        System.out.println("Tool 13 Start!");

        try {
//            Tool13HibernateTest tool13HibernateTest = new Tool13HibernateTest(FOLDER_IN_DIR);
            for (String path : fileInPathLists){
                System.out.println(path);
                logger.info(ViettelEncryptDecryptUtil.decryptFile(path));
            }
        } catch (Throwable ex) {
            logger.error("Error: ", ex);
        }
        logger.info("Tool 13 Complete!");
        System.out.println("Tool 13 Complete!");
    }
}
