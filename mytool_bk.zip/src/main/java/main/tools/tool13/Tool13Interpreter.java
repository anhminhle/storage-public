/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.tools.tool13;
import com.viettel.eafs.dataaccess.config.HibernateSessionFactoryConfig;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
/**
 *
 * @author minhla2
 */
public class Tool13Interpreter extends com.viettel.eafs.dataaccess.interpreter.HibernateFactoryXMLConfigurationInterpreter{
    
    private static Logger logger = Logger.getLogger(Tool13.class);

    public Tool13Interpreter(Tool13HibernateConnector conn) {
        super(conn);
    }
    
    public Tool13HibernateConnector getTool13conn(){
        return (Tool13HibernateConnector) super.getConn();
    }
    
    public void tool13Interprete(String filePath) throws Throwable{
        try {
            HashMap<String, HibernateSessionFactoryConfig> factoryConfigMap = new HashMap<String, HibernateSessionFactoryConfig>();
            String path = filePath;
            String stripped = path.startsWith("/") ? path.substring(1) : path;
//            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
            InputStream xml = new FileInputStream(new java.io.File(stripped));
            SAXReader reader = new SAXReader();
            Document doc = reader.read(xml);
            Element root = doc.getRootElement();
            Iterator<Element> itr = root.elements().iterator();
            Element commonNode = itr.next();
            String _defSesName = commonNode.elementText("defaultSessionName");
            HibernateSessionFactoryConfig.setDefaultSessionName(_defSesName);
            Element factoriesNode = itr.next();
            for (Iterator<Element> itemsItr = factoriesNode.elements().iterator(); itemsItr.hasNext(); ) {
                Element factoryNode = itemsItr.next();
                String sesName = factoryNode.elementText("sessionName");
                String cfgFilePath = factoryNode.elementText("configFilePath");
                String ecfgFilePath = factoryNode.elementText("encryptedConfigFilePath");
                HibernateSessionFactoryConfig factCfg = new HibernateSessionFactoryConfig(sesName, cfgFilePath, ecfgFilePath);
                if (ecfgFilePath != null && ecfgFilePath.length() > 0) {
                    factCfg.setIsEncrypted(Boolean.valueOf(true));
                    factCfg.setEncryptedProperties(readEncryptedConfigProperties(ecfgFilePath));
                } 
                factoryConfigMap.put(sesName, factCfg);
                System.out.println("Output to Log!");
                logger.info("Read: " + factCfg.getSessionName() + ", file: " + factCfg.getConfigFilePath() + " efile: " + factCfg.getIsEncrypted());
                List<String> encryptedProperties = Arrays.asList(factCfg.getEncryptedProperties());
                
                //run chcp on the command line to determine the encoding
                for (String prop: encryptedProperties){
                    logger.info(prop);
                }
                logger.info(_defSesName);
            } 
//            getTool13conn().tool13ApplyConfiguration(factoryConfigMap, _defSesName);
        } catch (Throwable tr) {
            logger.error("Loi khi doc cau hinh factory", tr);
            throw tr;
        } 
    }
}
