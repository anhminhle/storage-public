/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool9;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import constants.Constants;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
public class Tool9{
    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool9/";
    final String CONFIG_DIR = TOOL_DIR + "configTool9.properties";
    final String FOLDER_IN_DIR = TOOL_DIR + "In/";
    final String FOLDER_OUT_DIR = TOOL_DIR + "Out/";
    final String URL_IN_FILE = FOLDER_IN_DIR + "url.txt";
    Boolean doAuthenticate;
    Boolean doFindString;
    String stringToFind;
    String username;
    String password;
    List<String> inUrls;

    public void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(FOLDER_IN_DIR));
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        GeneralUtils.createFileIfNotExists(CONFIG_DIR);
        GeneralUtils.createFileIfNotExists(URL_IN_FILE);
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {
            Properties prop = new Properties();
            // load a properties file
            prop.load(input);
            doAuthenticate = prop.get("doAuthenticate").equals("1");
            username = prop.getProperty("username");
            password = prop.getProperty("password");
            doFindString = prop.get("doFindString").equals("1");
            stringToFind = prop.getProperty("stringToFind");
        }
        String textInUrls = new String(Files.readAllBytes(Paths.get(URL_IN_FILE)), "UTF-8");
        inUrls = Arrays.asList(textInUrls.replaceAll("\r", "").split("\n"));
    }

    public void urlToHTMLText(String url, String filePathOut) throws IOException{
        GeneralUtils.createFileIfNotExists(filePathOut);
        java.net.URL website = new java.net.URL(url);
        try (
            ReadableByteChannel channel = Channels.newChannel(website.openStream());
            FileOutputStream stream = new FileOutputStream(filePathOut);
                )
        {
            stream.getChannel().transferFrom(channel, 0, Long.MAX_VALUE);
            System.out.println("Download successful.");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Download was not successful.");
        }
    }

    public void urlToHTMLText(String url, String filePathOut, String login, String password) throws IOException{
        Authenticator.setDefault(new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(login, password.toCharArray());
            }
        });
        urlToHTMLText(url, filePathOut);
    }

    // find string in folder filePathIn then out to filePathOut
    public void tool9FindString(String stringToFind, String filePathIn, String filePathOut) throws IOException{
        String textIn = new String(Files.readAllBytes(Paths.get(filePathIn)), "UTF-8");
        int startPos = 0;
        int range = 300;
        try(
            FileWriter writer = new FileWriter(filePathOut);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
        ){
            while ((startPos = (textIn.indexOf(stringToFind, startPos))) != -1){
                int begin = startPos - range >= 0 ? startPos - range : 0;
                int end = startPos + range < textIn.length() ? startPos + range : textIn.length();
                String findText = textIn.substring(begin, end);
                bufferedWriter.write(findText);
                bufferedWriter.newLine();
                bufferedWriter.newLine();
                startPos = end - stringToFind.length();
            }
        }
    }

    public void appendToFile(String text, String filePathOut) throws IOException{
        try(
            FileWriter writer = new FileWriter(filePathOut, true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
        ){
            bufferedWriter.write(text);
        }
    }

    public void main() throws IOException{
        init();
        for (int i=0;i<inUrls.size();i++){
            String filePathOut = FOLDER_OUT_DIR + "out" + i + ".html";
            if (doAuthenticate) {
                urlToHTMLText(inUrls.get(i), filePathOut, username, password);
            }else{
                urlToHTMLText(inUrls.get(i), filePathOut);
            }
            if (doFindString){
                String filePathStringOut = FOLDER_OUT_DIR + "outString" + i + ".html";
                tool9FindString(stringToFind, filePathOut, filePathStringOut);
                appendToFile(inUrls.get(i) + "\r\n", filePathStringOut);
            }
        }
    }
}
