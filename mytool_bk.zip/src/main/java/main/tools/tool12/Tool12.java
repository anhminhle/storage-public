/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.tools.tool12;

import constants.Constants;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import org.apache.log4j.Logger;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
public class Tool12 {
    private static final Logger logger = Logger.getLogger(Tool12.class);

    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool12/";
    final String CONFIG_DIR = TOOL_DIR + "configTool12.properties";
    final String FOLDER_IN_DIR = TOOL_DIR + "In/";
    final String FOLDER_OUT_DIR = TOOL_DIR + "Out/";
    final String IN_ENCRYPTED_DIR = FOLDER_IN_DIR + "InEncryptedStrings.txt";
    final String IN_DECRYPTED_DIR = FOLDER_IN_DIR + "inDecryptedStrings.txt";
    final String OUT_ENCRYPTED_DIR = FOLDER_OUT_DIR + "outEncryptedStrings.txt";
    final String OUT_DECRYPTED_DIR = FOLDER_OUT_DIR + "outDecryptedStrings.txt";
    List<String> inEncryptedStringsList;
    List<String> inDecryptedStringsList;
    List<String> outEncryptedStringsList;
    List<String> outDecryptedStringsList;

    public void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(FOLDER_IN_DIR));
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        GeneralUtils.createFileIfNotExists(CONFIG_DIR);
        GeneralUtils.createFileIfNotExists(IN_ENCRYPTED_DIR);
        GeneralUtils.createFileIfNotExists(IN_DECRYPTED_DIR);
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            String InEncryptStringsText = new String(Files.readAllBytes(Paths.get(IN_ENCRYPTED_DIR)), "UTF-8");
            inEncryptedStringsList = Arrays.asList(InEncryptStringsText.replaceAll("\r", "").split("\n"));
            if (inEncryptedStringsList == null) inEncryptedStringsList = new ArrayList<>();
            String InDecryptStringsText = new String(Files.readAllBytes(Paths.get(IN_DECRYPTED_DIR)), "UTF-8");
            inDecryptedStringsList = Arrays.asList(InDecryptStringsText.replaceAll("\r", "").split("\n"));
        }
    }

    public void main() throws IOException, ClassNotFoundException, SQLException, Exception{
        init();
        logger.info("Tool 12 Start!");
        System.out.println("Tool 12 Start!");
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        GeneralUtils.deleteFileIfExists(OUT_ENCRYPTED_DIR);
        GeneralUtils.createFileIfNotExists(OUT_ENCRYPTED_DIR);
        GeneralUtils.deleteFileIfExists(OUT_DECRYPTED_DIR);
        GeneralUtils.createFileIfNotExists(OUT_DECRYPTED_DIR);

        outEncryptedStringsList = new ArrayList<>();
        for (String str:inEncryptedStringsList){
            String strg = new String(Tool12Utils.decrypt(Tool12Utils.stringToBytes(str)));
            GeneralUtils.appendToFile(str + " --- " + strg + "\r\n", OUT_ENCRYPTED_DIR, true);
            outEncryptedStringsList.add(strg);
        }

        outDecryptedStringsList = new ArrayList<>();
        for (String str:inDecryptedStringsList){
            String strg = new String(Tool12Utils.encrypt(Tool12Utils.stringToBytes(str)));
            GeneralUtils.appendToFile(str + " --- " + strg + "\r\n", OUT_DECRYPTED_DIR, true);
            outDecryptedStringsList.add(strg);
        }
        logger.info("Tool 12 Complete!");
        System.out.println("Tool 12 Complete!");
    }
}
