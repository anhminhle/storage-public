/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.tools.tool12;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

/**
 *
 * @author minhla2
 */
public class Tool12Utils {

    private static final int[] ascii = new int[] {
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
      2, 3, 4, 5, 6, 7, 8, 9, 0, 0,
      0, 0, 0, 0, 0, 10, 11, 12, 13, 14,
      15, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 10, 11, 12,
      13, 14, 15, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0 };

    private static byte[] key = new byte[] { -95, -29, -62, 25, 25, -83, -18, -85 };

    private static String algorithm = "DES";

    private static SecretKeySpec keySpec = new SecretKeySpec(key, algorithm);

    public static byte[] encrypt(byte[] arrByte) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(1, keySpec);
        byte[] data = cipher.doFinal(arrByte);
        return data;
    }

    public static byte[] decrypt(byte[] arrByte) throws Exception {
      Cipher cipher = Cipher.getInstance(algorithm);
      cipher.init(2, keySpec);
      return cipher.doFinal(arrByte);
    }


    public static byte[] stringToBytes(String s) {
        return stringToBytes(s, 0);
    }

    public static byte[] stringToBytes(String s, int minLength) {
        if (s.length() % 2 != 0)
            s = "0".concat(s);
        int len = s.length() / 2;
        int padLength = len;
        if (padLength < minLength)
            padLength = minLength;
        int offset = padLength - len;
        byte[] b = new byte[padLength];
        for (int i = 0; i < len; i++) {
            b[i + offset] = (byte)(hexToInt(s.charAt(i * 2)) << 4);
            b[i + offset] = (byte)(b[i + offset] | hexToInt(s.charAt(i * 2 + 1)) & 0xF);
        }
        return b;
    }

    public static int hexToInt(char c) {
        return ascii[c & 0x7F];
      }

    public static void main(String[] args) throws Exception {
        System.out.println(decrypt(stringToBytes("2be98afc86aa7f2e4cb79ce108fc7fd8b")));
        // System.out.println(encryptPassword(password));
        // System.out.println(decryptPassword(encryptPassword(password).substring("Encrypted2 ".length())));
    }
}
