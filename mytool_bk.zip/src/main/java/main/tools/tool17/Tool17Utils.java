package main.tools.tool17;

import java.math.BigInteger;

import main.tools.tool12.Tool12Utils;

public class Tool17Utils {
  private static final int RADIX = 16;

  private static final String SEED = "1355710983491427296129387048972677763974";

  public static final String ENCRYPTED_PREFIX = "Encrypted2 ";

  public static final String encryptPassword(String password) {
    if (password == null)
      return "";
    if (password.length() == 0)
      return "";
    BigInteger bi_passwd = new BigInteger(password.getBytes());
    BigInteger bi_r0 = new BigInteger("1355710983491427296129387048972677763974");
    BigInteger bi_r1 = bi_r0.xor(bi_passwd);
    return "Encrypted2 " + bi_r1.toString(16);
  }

  public static final String decryptPassword(String encrypted) {
    if (encrypted == null)
      return "";
    if (encrypted.length() == 0)
      return "";
    BigInteger bi_confuse = new BigInteger("1355710983491427296129387048972677763974");
    try {
      BigInteger bi_r1 = new BigInteger(encrypted, 16);
      BigInteger bi_r0 = bi_r1.xor(bi_confuse);
      return new String(bi_r0.toByteArray());
    } catch (Exception var4) {
      return "";
    }
  }

  public static final String decryptPasswordOptionallyEncrypted(String password) {
    return (password.startsWith("Encrypted2 ")) ?
      decryptPassword(password.substring("Encrypted2 ".length())) : password;
  }

  public static void main(String[] args) {
    String password = "Cus@DAC#321";
    System.out.println(decryptPassword("2be98afc86aa7f2e4cb79ce108fc7fd8b"));
    System.out.println(encryptPassword(password));
    // System.out.println(decryptPassword(encryptPassword(password).substring("Encrypted2 ".length())));
  }
}