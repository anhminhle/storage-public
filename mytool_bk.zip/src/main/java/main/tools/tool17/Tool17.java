package main.tools.tool17;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import constants.Constants;
import main.tools.tool17.Tool17Utils;
import utils.GeneralUtils;
import utils.ToolUtils;

/**
 *
 * @author minhla2
 * Encrypt/Decrypt ETL Designer Viettel (starts with Encrypted 2)
 */
public class Tool17 {
    private static final Logger logger = Logger.getLogger(Tool17.class);
    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool17/";
    final String CONFIG_DIR = TOOL_DIR + "configTool17.properties";
    final String FOLDER_IN_DIR = TOOL_DIR;
    final String FOLDER_OUT_DIR = TOOL_DIR;
    final String IN_ENCRYPTED_DIR = FOLDER_IN_DIR + "inEcrypted.txt";
    final String IN_DECRYPTED_DIR = FOLDER_IN_DIR + "inDecrypted.txt";
    final String OUT_ENCRYPTED_DIR = FOLDER_OUT_DIR + "outEncrypted.txt";
    final String OUT_DECRYPTED_DIR = FOLDER_OUT_DIR + "outDecrypted.txt";
    public void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(FOLDER_IN_DIR));
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        GeneralUtils.createFileIfNotExists(CONFIG_DIR);
        GeneralUtils.createFileIfNotExists(IN_ENCRYPTED_DIR);
        GeneralUtils.createFileIfNotExists(IN_DECRYPTED_DIR);
        GeneralUtils.createFileIfNotExists(OUT_ENCRYPTED_DIR);
        GeneralUtils.createFileIfNotExists(OUT_DECRYPTED_DIR);
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {
            Properties prop = new Properties();
            // load a properties file
            prop.load(input);
        }
    }
    public void main() throws IOException{
        init();
        logger.info("Tool 17 Start!");
        System.out.println("Tool 17 Start!");
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        GeneralUtils.deleteFileIfExists(OUT_ENCRYPTED_DIR);
        GeneralUtils.createFileIfNotExists(OUT_ENCRYPTED_DIR);
        GeneralUtils.deleteFileIfExists(OUT_DECRYPTED_DIR);
        GeneralUtils.createFileIfNotExists(OUT_DECRYPTED_DIR);

        List<String> inEncryptedStringsList;
        List<String> inDecryptedStringsList;
        List<String> outEncryptedStringsList;
        List<String> outDecryptedStringsList;

        String InEncryptStringsText = new String(Files.readAllBytes(Paths.get(IN_ENCRYPTED_DIR)), "UTF-8");
        inEncryptedStringsList = Arrays.asList(InEncryptStringsText.replaceAll("\r", "").split("\n"));
        if (inEncryptedStringsList == null) inEncryptedStringsList = new ArrayList<>();
        String InDecryptStringsText = new String(Files.readAllBytes(Paths.get(IN_DECRYPTED_DIR)), "UTF-8");
        inDecryptedStringsList = Arrays.asList(InDecryptStringsText.replaceAll("\r", "").split("\n"));

        outEncryptedStringsList = new ArrayList<>();
        for (String str:inEncryptedStringsList){
            String strg = new String(Tool17Utils.decryptPasswordOptionallyEncrypted(str));
            GeneralUtils.appendToFile(str + " --- " + strg + "\r\n", OUT_ENCRYPTED_DIR, true);
            outEncryptedStringsList.add(strg);
        }

        outDecryptedStringsList = new ArrayList<>();
        for (String str:inDecryptedStringsList){
            String strg = new String(Tool17Utils.encryptPassword(str));
            GeneralUtils.appendToFile(str + " --- " + strg + "\r\n", OUT_DECRYPTED_DIR, true);
            outDecryptedStringsList.add(strg);
        }
        logger.info("Tool 17 Complete!");
        System.out.println("Tool 17 Complete!");
    }
}
