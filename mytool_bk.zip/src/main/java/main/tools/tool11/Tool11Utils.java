/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.tools.tool11;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

/**
 *
 * @author minhla2
 */
public class Tool11Utils {
    // File delimiter: |
    public static void executeQueryAndOutToFile(Connection conn, String sqlQuery, String filePathOut) throws IOException, SQLException{
        int bufferSize = 2048;
        try(
            PreparedStatement ps = conn.prepareStatement(sqlQuery);
            ResultSet rs = ps.executeQuery();
            FileWriter writer = new FileWriter(filePathOut);

            BufferedWriter out = new BufferedWriter(writer, bufferSize * 1024);
        ){
            rs.setFetchSize(10000);
            ResultSetMetaData rsm = rs.getMetaData();

            out.write(sqlQuery);
            out.write("\n");

            String tmpHeader = rsm.getColumnName(1);
            for (int i = 1; i < rsm.getColumnCount(); i++) {
                tmpHeader += "|" + rsm.getColumnName(i + 1);
            }

            out.write(tmpHeader);
            out.write("\n");

            while (rs.next()) {
                String rowtmp = rs.getString(1);
                for (int i = 1; i < rsm.getColumnCount(); i++) {
                    rowtmp += "|" + rs.getString(i + 1);
                }
                out.write(rowtmp);
                out.write("\n");
            }

            out.flush();
            out.close();
        }
    }
}
