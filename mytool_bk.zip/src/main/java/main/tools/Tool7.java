/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools;

import constants.Constants;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import okhttp3.Response;
import utils.GeneralUtils;
import utils.mocha.MochaConstants;
import utils.mocha.MochaUtils;

/**
 *
 * @author minhla2
 * sendImgsMocha
 */
public class Tool7{
    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool7/";
    final String CONFIG_DIR = TOOL_DIR + "configTool7.properties";
    final String FOLDER_IN_DIR = TOOL_DIR + "In/";
    final String FOLDER_OUT_DIR = TOOL_DIR + "Out/";
    final String URL_OUT_DIR = FOLDER_OUT_DIR + "mochaUrls.txt";
    final String TELS_FILE_DIR = TOOL_DIR + "listTels.txt";
    final String TELS_ACCEPTED_FILE_DIR = TOOL_DIR + "listTelsAccepted.txt";
    final String RESPONSE_UPLOAD_OUT_DIR = FOLDER_OUT_DIR + "responseUploadOut.txt";
    final String RESPONSE_SEND_OUT_DIR = FOLDER_OUT_DIR + "responseSendOut.txt";
    List<String> listTels;
    List<String> listTelsAccepted;
    Boolean doUpload;
    Boolean doSend;

    private void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(FOLDER_IN_DIR));
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        try{Files.createFile(Paths.get(CONFIG_DIR));}catch (FileAlreadyExistsException ex){}
        try{Files.createFile(Paths.get(TELS_FILE_DIR));}catch (FileAlreadyExistsException ex){}
        try{Files.deleteIfExists(Paths.get(RESPONSE_UPLOAD_OUT_DIR));
            Files.createFile(Paths.get(RESPONSE_UPLOAD_OUT_DIR));}catch (FileAlreadyExistsException ex){}
        try{Files.deleteIfExists(Paths.get(RESPONSE_SEND_OUT_DIR));
            Files.createFile(Paths.get(RESPONSE_SEND_OUT_DIR));}catch (FileAlreadyExistsException ex){}

        try (InputStream input = new FileInputStream(CONFIG_DIR)) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            doUpload = prop.get("doUpload").equals("1");
            doSend = prop.get("doSend").equals("1");
            String textTels = new String(Files.readAllBytes(Paths.get(TELS_FILE_DIR)), "UTF-8");
            listTels = Arrays.asList(textTels.replaceAll("\r", "").split("\n"));
            String textTelsAccepted = new String(Files.readAllBytes(Paths.get(TELS_ACCEPTED_FILE_DIR)), "UTF-8");
            listTelsAccepted = Arrays.asList(textTelsAccepted.replaceAll("\r", "").split("\n"));

            if (doUpload){
                try{Files.deleteIfExists(Paths.get(URL_OUT_DIR));
                Files.createFile(Paths.get(URL_OUT_DIR));}catch (FileAlreadyExistsException ex){}
            }
        }
    }

    public void uploadImgMocha(String filePathIn, String urlFilePathOut, String resFilePathOut) throws IOException{
        try(
                FileWriter writer = new FileWriter(urlFilePathOut, true);
                BufferedWriter bufferedWriter = new BufferedWriter(writer);
                FileWriter resWriter = new FileWriter(resFilePathOut, true);
                BufferedWriter bufferedResWriter = new BufferedWriter(resWriter);
                ){
            Response resultMocha = MochaUtils.uploadIMGFile(MochaConstants.MOCHA_VTT_USERNAME, MochaConstants.MOCHA_VTT_PASSWORD, new File(filePathIn));
            String sout = resultMocha.body().string();
            bufferedResWriter.write(sout);
            bufferedResWriter.newLine();
            String[] a1 = sout.split("\\[");
            String[] a2 = a1[1].split(":");
            String[] a3 = a2[1].split(",");
            // String url = a3[0].substring(1, a3[0].length() - 1);
            bufferedWriter.write(sout);
            bufferedWriter.newLine();
        }
    }

    public void uploadImgsInFolder() throws IOException{
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(FOLDER_IN_DIR))) {
            for (Path path : stream) {
                if (!Files.isDirectory(path)) {
                    String filePathIn = path.toString();
                    uploadImgMocha(filePathIn, URL_OUT_DIR, RESPONSE_UPLOAD_OUT_DIR);
                    Logger.getLogger(Tool4.class.getName()).log(Level.INFO, "Xong {0}", filePathIn);
                }
            }
        }
    }

    public void sendImgs() throws IOException{

        try(
            FileWriter writer = new FileWriter(RESPONSE_SEND_OUT_DIR, true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
            ){
            String textUrls = new String(Files.readAllBytes(Paths.get(URL_OUT_DIR)), "UTF-8");
            List<String> listUrls = Arrays.asList(textUrls.replaceAll("\r", "").split("\n"));
            for (String tel: listTels){
                if (!listTelsAccepted.contains(tel)){
                    Logger.getLogger(Tool4.class.getName()).log(Level.INFO, "Khong gui cho so {0}", new Object[]{tel});
                }else{
                    String isdn = GeneralUtils.standardPhoneNumber(tel.trim());
                    for (String url: listUrls){
                        Response resultMocha = MochaUtils.sendIMGMocha(
                        MochaConstants.MOCHA_VTT_USERNAME,
                        MochaConstants.MOCHA_VTT_PASSWORD,
                        MochaConstants.MOCHA_VTT_OA,
                        isdn, url, MochaConstants.TYPE2);
                        bufferedWriter.write(resultMocha.body().string());
                        bufferedWriter.newLine();
                        Logger.getLogger(Tool4.class.getName()).log(Level.INFO, "Xong {0} {1}", new Object[]{isdn, url});
                    }
                }
            }
        }
    }

    public void main() throws IOException{
        init();
        if (doUpload) uploadImgsInFolder();
        if (doSend) sendImgs();
    }
}
