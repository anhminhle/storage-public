/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool18;

import constants.Constants;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import utils.DBProcessUtils;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
//gen insert query from query (Oracle)
public class Tool18 {
//    private static final Logger logger = Logger.getLogger(Tool11.class);
    private static final Logger logger = Logger.getLogger(Tool18.class);

    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool18/";
    final String CONFIG_DIR = TOOL_DIR + "configTool18.properties";
    final String FOLDER_IN_DIR = TOOL_DIR + "In/";
    final String FOLDER_OUT_DIR = TOOL_DIR + "Out/";
    final String SQL_SCRIPT_DIR = FOLDER_IN_DIR + "sqlScript.txt";
    String dbDriver;
    String dbUrl;
    String dbUser;
    String dbPass;
    String sqlScript;
    List<String> queriesList;
    Boolean oneConnectionOnly = false;

    public void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(FOLDER_IN_DIR));
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        GeneralUtils.createFileIfNotExists(CONFIG_DIR);
        GeneralUtils.createFileIfNotExists(SQL_SCRIPT_DIR);
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            // get the property value and print it out
            dbDriver = prop.getProperty("dbDriver");
            dbUrl = prop.getProperty("dbUrl");
            dbUser = prop.getProperty("dbUser");
            dbPass = prop.getProperty("dbPass");
            oneConnectionOnly = prop.get("oneConnectionOnly").equals("1");

            sqlScript = new String(Files.readAllBytes(Paths.get(SQL_SCRIPT_DIR)), "UTF-8");
            queriesList = Arrays.asList(sqlScript.split(";"));
        }
    }

    public void main() throws IOException, ClassNotFoundException, SQLException{
        init();
        // logger.info("Tool 18 Start!");
        System.out.println("Tool 18 Start!");
        String timeStamp = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(new java.util.Date());
        String outFileDir = FOLDER_OUT_DIR;
        Files.createDirectories(Paths.get(outFileDir));

        System.out.println("Connecting... " + dbUrl);
        try (Connection connMaster = DBProcessUtils.getConnection(dbDriver, dbUrl, dbUser, dbPass)){
            System.out.println("Connection successful!");
            String outFileName="insertScript";
            String outFilePath = outFileDir + outFileName + ".txt";
            GeneralUtils.deleteFileIfExists(outFilePath);
            GeneralUtils.createFileIfNotExists(outFilePath);
            for (int i=0;i<queriesList.size();i++){
                String query = queriesList.get(i).trim();
                System.out.println("Executing query " + i + "...");
                // logger.info("Executing query: " + StringUtils.left(query, 40) + "...");
                // logger.info("Output to file: " + outFilePath);
                if (oneConnectionOnly){
                    Tool18Utils.exAndGenInsertQueriesOracle(connMaster, query, outFilePath);
                }else{
                    try (Connection conn = DBProcessUtils.getConnection(dbDriver, dbUrl, dbUser, dbPass)){
                        Tool18Utils.exAndGenInsertQueriesOracle(conn, query, outFilePath);
                    }
                }
                System.out.println("Executing query " + i + " complete!");
                // logger.info("Execute query complete!");
                GeneralUtils.openFileDesktop(outFilePath);
            }
        }
    }
}
