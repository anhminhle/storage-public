/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.tools.tool18;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Scanner;

import org.apache.commons.lang3.StringUtils;

import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
public class Tool18Utils {
    public static void exAndGenInsertQueriesOracle(Connection conn, String sqlQuery, String filePathOut) throws IOException, SQLException{
        int bufferSize = 2048;
        try(
            PreparedStatement ps = conn.prepareStatement(sqlQuery);
            ResultSet rs = ps.executeQuery();
        ){
            rs.setFetchSize(10000);
            ResultSetMetaData rsm = rs.getMetaData();

            String tmpComment = "--" + StringUtils.left(sqlQuery, 70) + System.lineSeparator();
            GeneralUtils.dumpStringsToFile(tmpComment, filePathOut, true);

            if (rsm.getColumnCount() > 1000){
                try(Scanner console = new Scanner(System.in)){
                    String x;
                    do{
                        System.out.println("Query over 1000 rows - continue? (Y/N):");
                        x = console.nextLine();
                    }while (!"Y".equals(x) && !"N".equals(x));
                    if ("N".equals(x)) return;
                }
            }
            String tmpHeader = "INSERT INTO tmp_abc" + System.lineSeparator() + "(" + rsm.getColumnName(1);
            for (int i = 1; i < rsm.getColumnCount(); i++) {
                tmpHeader += ", " + rsm.getColumnName(i + 1);
            }
            tmpHeader += ")" + System.lineSeparator();

            GeneralUtils.dumpStringsToFile(tmpHeader, filePathOut, true);

            boolean isNotEnd = rs.next();
            while (isNotEnd) {
                String rowtmp = "SELECT ";
                for (int i = 1; i <= rsm.getColumnCount(); i++) {
                    String val = rs.getString(i);
                    String className = rsm.getColumnClassName(i);
                    if ("java.lang.String".equals(className)){
                        val = "'" + val + "'";
                    }else if ("java.math.BigDecimal".equals(className)){
                        //int, do nothing
                    }
                    if (i != rsm.getColumnCount()) val += ", ";
                    rowtmp += val;
                }
                rowtmp += " from dual";
                isNotEnd = rs.next();
                if (isNotEnd) rowtmp += " union all" + System.lineSeparator();
                else rowtmp += ";" + System.lineSeparator();
                GeneralUtils.dumpStringsToFile(rowtmp, filePathOut, true);
            }
        }
    }

}
