/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools;

import constants.Constants;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DBProcessUtils;

/**
 *
 * @author minhla2
 * OraInsertBlob
 */
public class Tool3{
    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool3/";
    final String CONFIG_DIR = TOOL_DIR + "configTool3.properties";
    final String BLOB_FILES_DIR = TOOL_DIR + "blobInFiles";
    final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    final String QUERY_DIR = TOOL_DIR + "query.txt";
    String dbDriver;
    String dbUrl;
    String dbUser;
    String dbPass;
    String queryStr;
    List<String> blobFilesPath;
    Boolean hasFileNames;
    
    public Tool3(){
    }
    
    private void init() throws IOException{
        try (
            InputStream conf = new FileInputStream(CONFIG_DIR);
            DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(BLOB_FILES_DIR));
        ) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(conf);

            // get the property value and print it out
            dbDriver = DB_DRIVER;
            dbUrl = prop.getProperty("dbUrl");
            dbUser = prop.getProperty("dbUser");
            dbPass = prop.getProperty("dbPass");
            hasFileNames = prop.get("hasFileNames").equals("1");
            
            blobFilesPath = new ArrayList<>();
            for (Path path : stream) {
                if (!Files.isDirectory(path)) {
                    String filePath = path.toString();
                    blobFilesPath.add(filePath);
                }
            }
            queryStr = new String(Files.readAllBytes(Paths.get(QUERY_DIR)), "UTF-8");
        }
        
    }
    
    public void main() throws ClassNotFoundException, SQLException, IOException{
        init();
        try (
            Connection conn = DBProcessUtils.getConnection(dbDriver, dbUrl, dbUser, dbPass);
            PreparedStatement statement = conn.prepareStatement(queryStr)
        ){
            for (String filePath : blobFilesPath){
                File blob = new File(filePath);
                InputStream in = new FileInputStream(filePath);
                if (hasFileNames) statement.setString(1, blob.getName());
                statement.setBinaryStream(2, in, (int) blob.length());
                statement.executeQuery();
                Logger.getLogger(Tool3.class.getName()).log(Level.INFO, "Insert {0}", blob.getName());
            }
        }
    }
}
