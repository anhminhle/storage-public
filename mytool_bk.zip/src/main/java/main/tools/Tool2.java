/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools;

import constants.Constants;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.sql.BLOB;
import org.apache.commons.io.IOUtils;
import utils.DBProcessUtils;

/**
 *
 * @author minhla2
 * OraQueryExportFiles
 */
public class Tool2{
    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool2/";
    final String CONFIG_DIR = TOOL_DIR + "configTool2.properties";
    final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    final String BLOB_OUT_DIR = TOOL_DIR + "blobOutFiles";
    final String QUERY_DIR = TOOL_DIR + "query.txt";
    String dbDriver;
    String dbUrl;
    String dbUser;
    String dbPass;
    String queryStr;
    Boolean hasFileNames;
    String fileNameColumn;
    String fileContentColumn;
    
    public Tool2(){
    }
    
    private void init() throws IOException{
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            // get the property value and print it out
            dbDriver = DB_DRIVER;
            dbUrl = prop.getProperty("dbUrl");
            dbUser = prop.getProperty("dbUser");
            dbPass = prop.getProperty("dbPass");
            hasFileNames = prop.get("hasFileNames").equals("1");
            fileNameColumn = prop.getProperty("fileNameColumn");
            fileContentColumn = prop.getProperty("fileContentColumn");
            
            queryStr = new String(Files.readAllBytes(Paths.get(QUERY_DIR)), "UTF-8");
        }
    }
    
    public void main() throws ClassNotFoundException, SQLException, IOException{
        init();
        try (
            Connection conn = DBProcessUtils.getConnection(dbDriver, dbUrl, dbUser, dbPass);
            PreparedStatement statement = conn.prepareStatement(queryStr)
        ){
            ResultSet resultSet = statement.executeQuery();
            int fileCount = 0;
            while (resultSet.next()){
                fileCount++;
                String fileName = hasFileNames ? resultSet.getString(fileNameColumn) : "File" + Integer.toString(fileCount);
                String filePathOut = BLOB_OUT_DIR + "/" + fileName;
                oracle.sql.BLOB fileContent = (BLOB)resultSet.getBlob(fileContentColumn);
                if (fileContent == null){
                    File file = new File(filePathOut);
                    file.createNewFile();
                }else{
                    try (                        
                        InputStream in = fileContent.getBinaryStream();
                        OutputStream out = new FileOutputStream(filePathOut)                    
                    ){
                        IOUtils.copy(in, out);
                    }
                }
                Logger.getLogger(Tool2.class.getName()).log(Level.INFO, "Copy {0}", fileName);
            }
        }
    }
}
