/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.tools.tool15;

import constants.Constants;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import okhttp3.Response;
import org.apache.log4j.Logger;
import utils.GeneralUtils;
import utils.mocha.MochaConstants;
import utils.mocha.MochaUtils;

/**
 *
 * @author minhla2
 * replace a string in a .docx file (.doc might work).
 */
public class Tool15 {
    private static final Logger logger = Logger.getLogger(Tool15.class);
    private static final Logger consoleLogger = Logger.getLogger("CONSOLE");

    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool15/";
    final String CONFIG_DIR = TOOL_DIR + "configTool15.properties";
    final String FOLDER_IN_DIR = TOOL_DIR + "In/";
    final String FOLDER_OUT_DIR = TOOL_DIR + "Out/";
    final String TEXT_DIR = FOLDER_IN_DIR + "text.txt";
    final String RESPONSE_OUT_DIR = FOLDER_OUT_DIR + "responseOut.txt";
    final String TELS_FILE_DIR = FOLDER_IN_DIR + "listTels.txt";
    final String TELS_ACCEPTED_FILE_DIR = FOLDER_IN_DIR + "listTelsAccepted.txt";
    List<String> listTelsAccepted;
    List<String> listTels;
    List<String> stringsList;
    String stringText;

    public void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(FOLDER_IN_DIR));
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        GeneralUtils.createFileIfNotExists(CONFIG_DIR);
        GeneralUtils.createFileIfNotExists(TEXT_DIR);
        GeneralUtils.createFileIfNotExists(TELS_FILE_DIR);
        GeneralUtils.createFileIfNotExists(TELS_ACCEPTED_FILE_DIR);
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);
            stringText = new String(Files.readAllBytes(Paths.get(TEXT_DIR)), "UTF-8");
            String textTels = new String(Files.readAllBytes(Paths.get(TELS_FILE_DIR)), "UTF-8");
            if (!textTels.isEmpty()) listTels = Arrays.asList(textTels.replaceAll("\r", "").split("\n"));
            else listTels = new ArrayList<>();
            String textTelsAccepted = new String(Files.readAllBytes(Paths.get(TELS_ACCEPTED_FILE_DIR)), "UTF-8");
            if (!textTelsAccepted.isEmpty()) listTelsAccepted = Arrays.asList(textTelsAccepted.replaceAll("\r", "").split("\n"));
            else listTelsAccepted = new ArrayList<>();
        }
    }
    public void main() throws IOException, ClassNotFoundException, SQLException{
        init();
        logger.info("Tool 15 Start!");
        System.out.println("Tool 15 Start!");
        GeneralUtils.deleteFileIfExists(RESPONSE_OUT_DIR);
        GeneralUtils.createFileIfNotExists(RESPONSE_OUT_DIR);

        for (String tel: listTels){
            if (!listTelsAccepted.contains(tel)){
                consoleLogger.info(String.format("Khong gui cho so {0}", new Object[]{tel}));
            }else{
                String isdn = GeneralUtils.standardPhoneNumber(tel.trim());
                Response resultMocha = MochaUtils.sendTextMocha(
                    MochaConstants.MOCHA_VTT_USERNAME,
                    MochaConstants.MOCHA_VTT_PASSWORD,
                    MochaConstants.MOCHA_VTT_OA,
                    isdn, stringText, MochaConstants.TYPE2);
                if (resultMocha != null){
                    GeneralUtils.appendToFile(resultMocha.body().string() + "\r\n",RESPONSE_OUT_DIR, true);
                    consoleLogger.info(String.format("Xong {0} {1}", new Object[]{isdn, stringText}));
                }else{
                    // FunctionUtils.appendToFile(resultMocha.body().string() + "\r\n",RESPONSE_OUT_DIR, true);
                    consoleLogger.info(String.format("Loi {0} {1}", new Object[]{isdn, stringText}));
                }
            }
        }
        logger.info("Tool 15 Complete!");
        System.out.println("Tool 15 Complete!");
    }
}
