/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools;

import constants.Constants;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author minhla2
 * FindStringsInFolder
 */
public class Tool4{
    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool4/";
    final String CONFIG_DIR = TOOL_DIR + "configTool4.properties";
    final String OUT_DIR = TOOL_DIR + "Out/";
    final String STRINGS_FILE_DIR = TOOL_DIR + "listStrings.txt";
    final String EXCLUDED_FILE_SUFFIXES_DIR = TOOL_DIR + "excludedFileSuffixes.txt";
    final String LOGS_DIR = TOOL_DIR + "logs/";
    final String OUT_FILE_DIR = OUT_DIR + "Out.txt";
    String fileOutSuffix;
    String folderInPath;
    Boolean isSeperatingFiles;
    Boolean matchCase;
    List<String> listStrings;
    List<String> excludedFileSuffixes;
    
    final 
    
    private void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(OUT_DIR));
        Files.createDirectories(Paths.get(LOGS_DIR));
        try{
            Files.deleteIfExists(Paths.get(OUT_FILE_DIR));
            Files.createFile(Paths.get(OUT_FILE_DIR));
            Files.createFile(Paths.get(CONFIG_DIR));
            Files.createFile(Paths.get(STRINGS_FILE_DIR));
            Files.createFile(Paths.get(EXCLUDED_FILE_SUFFIXES_DIR));
        }catch (FileAlreadyExistsException ex){
            // do nothing
        }
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            // get the property value and print it out
            folderInPath = prop.getProperty("folderInPath");
            fileOutSuffix = prop.getProperty("fileOutSuffix");
            isSeperatingFiles = prop.get("isSeperatingFiles").equals("1");
            matchCase = prop.get("matchCase").equals("1");
            
            String textStrings = new String(Files.readAllBytes(Paths.get(STRINGS_FILE_DIR)), "UTF-8");
            listStrings = Arrays.asList(textStrings.replaceAll("\r", "").split("\n"));
            textStrings = new String(Files.readAllBytes(Paths.get(EXCLUDED_FILE_SUFFIXES_DIR)), "UTF-8");
            excludedFileSuffixes = Arrays.asList(textStrings.replaceAll("\r", "").split("\n"));
        }
    }
    
    public static void writeLine(BufferedWriter bufferedWriter, List<String> lines, int index) throws IOException{
        if (index >=0 && index < lines.size()){
            bufferedWriter.write("Line " + index + ": " + lines.get(index));
            bufferedWriter.newLine();      
        }
    }
    
    // find str in line.
    public Boolean customFindStrings(String line, String str){
        Boolean result;
        if (!this.matchCase) result = StringUtils.containsIgnoreCase(line, str);
        else result = StringUtils.contains(line, str);
        return result;
    }
    
    public void findInFile(String filePathIn, BufferedReader bufferedReader, BufferedWriter bufferedWriter, String str) throws IOException{
        String line;
        int lineNo = 0;
        Boolean foundInFile = false;
        List<String> lines = new ArrayList<>();
        while ((line = bufferedReader.readLine( )) != null){
            lineNo++;
            lines.add(line);
        }
        for (int cur = 0; cur < lines.size(); cur++){
            if (this.customFindStrings(lines.get(cur),str))
            {
                if (!foundInFile){
                    bufferedWriter.write(filePathIn + " ---- " + str);
                    bufferedWriter.newLine();
                    foundInFile = true;
                }
                for (int index = cur-2;index<=cur+2;index++){
                    writeLine(bufferedWriter, lines, index);
                }
                bufferedWriter.newLine();
            }
        }
    }
    public void findInFile(String filePathIn, String filePathOut, String str) throws IOException{
        try(
                FileReader reader = new FileReader(filePathIn); 
                FileWriter writer = new FileWriter(filePathOut, true);
                BufferedReader bufferedReader = new BufferedReader(reader);
                BufferedWriter bufferedWriter = new BufferedWriter(writer);
                ){
            findInFile(filePathIn, bufferedReader, bufferedWriter, str);
        }
    }
    
    public Boolean isExcludedFile(String fileNameIn){
        return this.excludedFileSuffixes.stream().anyMatch((suffix) -> (fileNameIn.endsWith(suffix)));
    }
    
    public void findInFolder(String folderPathIn, String str, BufferedWriter outWriter) throws IOException{
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(folderPathIn))) {
            for (Path path : stream) {
                if (!Files.isDirectory(path)) {
                    String filePathIn = path.toString();
                    String fileNameIn = path.getFileName().toString();
                    if (!isExcludedFile(fileNameIn)){
                        try(    
                            FileReader reader = new FileReader(filePathIn); 
                            BufferedReader bufferedReader = new BufferedReader(reader);
                        ){
                            findInFile(filePathIn, bufferedReader, outWriter, str);
                        }
                    }else{
//                        Logger.getLogger(FindStringsInFolder.class.getName()).log(Level.INFO, "Bo qua {0} --- {1}", new Object[]{filePathIn, str});
                    }
                }else{
                    Logger.getLogger(Tool4.class.getName()).log(Level.INFO, "Den {0} --- {1}", new Object[]{path.toString(), str});
                    findInFolder(path.toString(), str, outWriter);
                }
            }
        }
    }
    public void findInFolder(String folderPathIn, String str) throws IOException{
        String fileNameOut; 
        fileNameOut = (isSeperatingFiles ? str
            : "out" ) + fileOutSuffix;
        String filePathOut = OUT_DIR + fileNameOut;
        try(
            FileWriter writer = new FileWriter(filePathOut, true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
        ){
            findInFolder(folderPathIn, str, bufferedWriter);
        }
    }
    
    
    public void main() throws ClassNotFoundException, SQLException, IOException{
        init();
        for (String str : listStrings){
            str = str.replace("\r", "");
            findInFolder(folderInPath, str);
            Logger.getLogger(Tool4.class.getName()).log(Level.INFO, "Xong {0}", str);
        }
    }
}
