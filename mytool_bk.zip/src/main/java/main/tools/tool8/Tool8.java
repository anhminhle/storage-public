/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool8;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import main.tools.tool8.printer.Tool8Printer;
import main.tools.tool8.scanner.Tool8Scanner;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */

// tim source table
public class Tool8 {
    final String TOOL_DIR = "tools/tool8/";
    final String CONFIG_DIR = TOOL_DIR + "configTool8.properties";
    final String INPUT_DIRS_FILE = TOOL_DIR + "inputDirs.txt";
    final String INCLUDED_FILE_SUFFIXES_DIR = TOOL_DIR + "includedFileSuffixes.txt";
    final String TABLE_NAMES_DIR = TOOL_DIR + "tableNames.txt";
    final String OUT_DIR = TOOL_DIR + "Out/";
    List<String> inputDirs;
    List<String> includedFileSuffixes;
    List<String> tableNames;
    Tool8Scanner tool8Scanner;
    Tool8Printer tool8Printer;

    public Tool8() throws IOException {
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(OUT_DIR));
        GeneralUtils.createFileIfNotExists(CONFIG_DIR);
        GeneralUtils.createFileIfNotExists(INPUT_DIRS_FILE);
        GeneralUtils.createFileIfNotExists(INCLUDED_FILE_SUFFIXES_DIR);
        String textInputDirs = new String(Files.readAllBytes(Paths.get(INPUT_DIRS_FILE)), "UTF-8");
        inputDirs = Arrays.asList(textInputDirs.replaceAll("\r", "").split("\n"));
        String textIncludedFileSuffixes = new String(Files.readAllBytes(Paths.get(INCLUDED_FILE_SUFFIXES_DIR)), "UTF-8");
        includedFileSuffixes = Arrays.asList(textIncludedFileSuffixes.replaceAll("\r", "").split("\n"));
        this.tool8Scanner = new Tool8Scanner(inputDirs, includedFileSuffixes);
        tool8Scanner.scan();
        this.tool8Printer = new Tool8Printer(tool8Scanner.getTool8Graph(), OUT_DIR);
    }


    private void init() throws IOException{
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {
            Properties prop = new Properties();
            // load a properties file
            prop.load(input);
        }
        String textTableNames = new String(Files.readAllBytes(Paths.get(TABLE_NAMES_DIR)), "UTF-8");
        tableNames = Arrays.asList(textTableNames.replaceAll("\r", "").split("\n"));
    }

    public void main() throws IOException{
        init();
        for (String tableName : tableNames){
            tool8Printer.printTable(tableName);
        }
    }
}
