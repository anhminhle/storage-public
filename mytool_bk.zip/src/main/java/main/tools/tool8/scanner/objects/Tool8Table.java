/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool8.scanner.objects;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author minhla2
 */
public class Tool8Table {
    private String tableName;
    private Set<String> parentTableNames;
    private List<Tool8Query> queries;

    public Tool8Table(String tableName) {
        this.tableName = tableName;
        parentTableNames = new HashSet<>();
        queries = new ArrayList<>();
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public Set<String> getParentTableNames() {
        return parentTableNames;
    }

    public void setParentTableNames(Set<String> parentTableNames) {
        this.parentTableNames = parentTableNames;
    }

    public List<Tool8Query> getQueries() {
        return queries;
    }

    public void setQueries(List<Tool8Query> queries) {
        this.queries = queries;
    }
    
}
