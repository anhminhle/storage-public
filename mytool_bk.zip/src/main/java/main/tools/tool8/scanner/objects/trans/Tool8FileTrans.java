/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool8.scanner.objects.trans;

import java.util.List;
import main.tools.tool8.scanner.objects.Tool8File;

/**
 *
 * @author minhla2
 */
public class Tool8FileTrans extends Tool8File{
    List<Tool8Step> steps;

    public Tool8FileTrans(String absolutePath, String content) {
        super(absolutePath, content);
    }
    
}
