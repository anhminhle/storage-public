/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool8.scanner.objects;

import java.util.Map;

/**
 *
 * @author minhla2
 */
public class Tool8Graph {
    private Map<String, Tool8Table> graph;

    public Tool8Graph(Map<String, Tool8Table> graph) {
        this.graph = graph;
    }

    public Map<String, Tool8Table> getGraph() {
        return graph;
    }

    public void setGraph(Map<String, Tool8Table> graph) {
        this.graph = graph;
    }
    
    
}
