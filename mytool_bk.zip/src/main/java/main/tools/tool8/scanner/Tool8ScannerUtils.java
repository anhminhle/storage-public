/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool8.scanner;

import main.tools.tool8.scanner.objects.Tool8File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import main.tools.tool8.scanner.objects.Tool8Query;
import main.tools.tool8.scanner.objects.Tool8Table;
import org.apache.commons.lang3.StringUtils;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
public class Tool8ScannerUtils {

    public static String strXmlToText(String xmlString){
        String result;
        result = StringUtils.replace(xmlString, "&apos;", "'");
        result = StringUtils.replace(result, "&#47;", "\\");
        result = StringUtils.replace(result, "&lt;", "<");
        result = StringUtils.replace(result, "&gt;", ">");
        result = StringUtils.replace(result, "&quot;", "\"");
        return result;
    }
    public static void insertFile(List<Tool8File> files, String filePathIn) throws IOException{
        String text = new String(Files.readAllBytes(Paths.get(filePathIn)), "UTF-8");
        text = strXmlToText(text);
        files.add(new Tool8File(filePathIn, text));
    }

    public static Boolean isIncludedFile(List<String> includedFileSuffixes, String fileNameIn){
        return includedFileSuffixes.stream().anyMatch((suffix) -> (fileNameIn.endsWith(suffix)));
    }

    public static List<String> extractSqlContents(String content){
        List<String> result = new ArrayList<>();
        int startPos = 0;
        String startsWith = "<sql>";
        String endsWith = "</sql>";
        do{
            List<Integer> pos = new ArrayList<>();
            GeneralUtils.findNextSubStrStartsAndEndsWith(content, startPos, startsWith, endsWith, pos);
            if (pos.isEmpty()) break;
            int begin = pos.get(0);
            int end = pos.get(1);
            String subStr = StringUtils.substring(content, begin + startsWith.length(), end - endsWith.length());
            result.add(subStr);
            startPos = end;
        }while (true);
        return result;
    }

    public static List<String> extractSqlFromSqlContents(String sqlContent){
        // bo toan bo comment
        List<String> result;
        sqlContent += "\r\n";      // Them de xu ly de hon
        do{
            String commentStr = GeneralUtils.findNextSubStrStartsAndEndsWith(sqlContent, 0, "--", "\r\n", new ArrayList<>());
            if (commentStr == null) break;
            sqlContent = StringUtils.replace(sqlContent, commentStr, "");
        }while(true);
        do{
            String commentStr = GeneralUtils.findNextSubStrStartsAndEndsWith(sqlContent, 0, "\\*", "*\\", new ArrayList<>());
            if (commentStr == null) break;
            sqlContent = StringUtils.replace(sqlContent, commentStr, "");
        }while(true);

        result = new ArrayList<>(Arrays.asList(sqlContent.split(";")));
        // bo element cuoi cung neu bi trong
        if (result.get(result.size()-1).trim().isEmpty()){
            result.remove(result.size()-1);
        }
        return result;
    }

    public static List<Tool8Query> extractQuery(Tool8File tool8File){
        List<Tool8Query> result = new ArrayList<>();
        List<String> sqlContents = extractSqlContents(tool8File.getContent());
        List<String> sqls = new ArrayList<>();
        sqlContents.stream().forEach((sqlContent) -> {
            sqls.addAll(extractSqlFromSqlContents(sqlContent));
        });
        sqls.stream().forEach((sql) -> {
            result.add(new Tool8Query(tool8File, sql + ";"));
        });
        return result;
    }

    // cho 1 query, tim cac word dung canh word 'from' hoac 'join'. Query khong co ky tu xuong dong.
    public static List<String> findRelatingTables(String query){
        List<String> result = new ArrayList<>();
        List<String> words = Arrays.asList(query.split(" "));
        Boolean isTable = false;
        for (String word: words){
            if (isTable && Pattern.compile("^[a-zA-Z0-9]").matcher(word).find()){       //startsWith
                while (!Pattern.compile("[a-zA-Z0-9]$").matcher(word).find())            //endsWith
                    word = StringUtils.chop(word);
                result.add(word);
            }
            isTable = word.equalsIgnoreCase("from") || word.equalsIgnoreCase("join");
        }
        return result;
    }

    public static void extractTableFromQuery(Map<String, Tool8Table> tablesMap, Tool8Query tool8Query){
        String transQuery2 = tool8Query.getTransQuery2();
        String tableName = null;
        List<String> fromTables = new ArrayList<>();
        switch (tool8Query.getType()){
            case INSERT:
                tableName = GeneralUtils.deleteStartsWithAnyIgnoreCase(transQuery2, Tool8Query.insertPrefix).trim().split("( )|(\\()", 2)[0];
                fromTables = findRelatingTables(transQuery2);
                break;
            case CREATE:
                tableName = GeneralUtils.deleteStartsWithAnyIgnoreCase(transQuery2, Tool8Query.createPrefix).trim().split("( )|(\\()", 2)[0];
                if (StringUtils.containsIgnoreCase(transQuery2, "AS")) fromTables = findRelatingTables(transQuery2);
                break;
            case DELETE:
                tableName = GeneralUtils.deleteStartsWithAnyIgnoreCase(transQuery2, Tool8Query.deletePrefix).trim().split("( )|(\\()", 2)[0];
                break;
            case UPDATE:
                tableName = GeneralUtils.deleteStartsWithAnyIgnoreCase(transQuery2, Tool8Query.updatePrefix).trim().split("( )|(\\()", 2)[0];
                fromTables = findRelatingTables(transQuery2);
                break;
            case ALTER:
                tableName = GeneralUtils.deleteStartsWithAnyIgnoreCase(transQuery2, Tool8Query.alterPrefix).trim().split("( )|(\\()", 2)[0];
                break;
            default:
        }

        if (tableName == null) return;

        if (!tablesMap.containsKey(tableName)) tablesMap.put(tableName, new Tool8Table(tableName));
        Tool8Table currentTable = tablesMap.get(tableName);
        currentTable.getQueries().add(tool8Query);
        for (String fromTableName : fromTables){
            if (!tablesMap.containsKey(fromTableName)) tablesMap.put(fromTableName, new Tool8Table(fromTableName));
            currentTable.getParentTableNames().add(fromTableName);
        }
    }
}
