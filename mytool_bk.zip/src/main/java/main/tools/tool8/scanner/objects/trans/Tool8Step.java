/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool8.scanner.objects.trans;

import java.util.ArrayList;
import org.apache.commons.lang3.StringUtils;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
public abstract class Tool8Step {
    enum StepType{
        TABLEINPUT,
        TABLEOUTPUT,
        UNK
    };

    private final StepType type;
    private String name;
    private String sql = null;
    private String table = null;

    public Tool8Step(String content) {
        String typeStr = GeneralUtils.findNextSubStrStartsAndEndsWith(content, 0, "<type>", "</type>", new ArrayList<>());
        if (StringUtils.containsIgnoreCase(typeStr, "TableInput")){
            this.type = StepType.TABLEINPUT;
        }else if (StringUtils.containsIgnoreCase(typeStr, "TableOutput")){
            this.type = StepType.TABLEOUTPUT;
        }else{
            this.type = StepType.UNK;
        }

        this.name = GeneralUtils.findNextSubStrStartsAndEndsWith(content, 0, "<name>", "</name>", new ArrayList<>());
        this.name = StringUtils.replace(this.name, "<name>", "");
        this.name = StringUtils.replace(this.name, "</name>", "");

        switch (this.type){
            case TABLEINPUT:
                this.sql = GeneralUtils.findNextSubStrStartsAndEndsWith(content, 0, "<sql>", "</sql>", new ArrayList<>());
                this.sql = StringUtils.replace(this.sql, "<sql>", "");
                this.sql = StringUtils.replace(this.sql, "</sql>", "");
                break;
            case TABLEOUTPUT:
                this.table = GeneralUtils.findNextSubStrStartsAndEndsWith(content, 0, "<table>", "</table>", new ArrayList<>());
                this.table = StringUtils.replace(this.table, "<table>", "");
                this.table = StringUtils.replace(this.table, "</table>", "");
                break;
            default:
        }
    }

}
