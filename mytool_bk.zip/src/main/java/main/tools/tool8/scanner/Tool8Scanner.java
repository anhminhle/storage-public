/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool8.scanner;

import main.tools.tool8.scanner.objects.Tool8File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import main.tools.tool8.scanner.objects.Tool8Graph;
import main.tools.tool8.scanner.objects.Tool8Query;
import main.tools.tool8.scanner.objects.Tool8Table;

/**
 *
 * @author minhla2
 */
public class Tool8Scanner {
    private List<String> inputDirs;
    private List<String> includedFileSuffixes;
    private List<Tool8File> tool8Files;
    private List<Tool8Query> tool8Queries;
    private Tool8Graph tool8Graph;

    public List<String> getInputDirs() {
        return inputDirs;
    }

    public List<String> getIncludedFileSuffixes() {
        return includedFileSuffixes;
    }

    public List<Tool8Query> getTool8Queries() {
        return tool8Queries;
    }

    public Tool8Graph getTool8Graph() {
        return tool8Graph;
    }

    public List<Tool8File> getTool8Files() {
        return tool8Files;
    }
    
    public Tool8Scanner(List<String> inputDirs, List<String> includedFileSuffixes) {
        this.inputDirs = inputDirs;
        this.includedFileSuffixes = includedFileSuffixes;
    } 
    
    public List<Tool8File> scanDir(String inputDir) throws IOException{
        List<Tool8File> result = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(inputDir))) {
            for (Path path : stream) {
                if (!Files.isDirectory(path)) {
                    String filePathIn = path.toString();
                    String fileNameIn = path.getFileName().toString();
                    if (Tool8ScannerUtils.isIncludedFile(includedFileSuffixes, fileNameIn)){
                        Tool8ScannerUtils.insertFile(result, filePathIn);
                    }
                }else{
                    Logger.getLogger(Tool8Scanner.class.getName()).log(Level.INFO, "Den {0}", new Object[]{path.toString()});
                    result.addAll(scanDir(path.toString()));
                }
            }
        }
        return result;
    }
    
    private List<Tool8Query> extractQueries(List<Tool8File> tool8Files){
        List<Tool8Query> result = new ArrayList<>();
        for (Tool8File tool8File : tool8Files){
            result.addAll(Tool8ScannerUtils.extractQuery(tool8File));
        }
        return result;
    }
    
    private Tool8Graph extractTables(List<Tool8Query> tool8Queries){
        Map<String, Tool8Table> result = new HashMap<>();
        tool8Queries.stream().forEach((tool8Query) -> {
            Tool8ScannerUtils.extractTableFromQuery(result, tool8Query);
        });
        return new Tool8Graph(result);
    }
    
    public void scan(){
        for (String inputDir : inputDirs){
            try {
                tool8Files = scanDir(inputDir);
                tool8Queries = extractQueries(tool8Files);
                tool8Graph = extractTables(tool8Queries);
            } catch (IOException ex) {
                Logger.getLogger(Tool8Scanner.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println("SCAN DONE!");
    }
}
