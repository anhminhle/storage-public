/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool8.scanner.objects;

import java.util.Arrays;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
public class Tool8Query {
    public enum QueryType{
        INSERT,
        UPDATE,
        SELECT,
        DELETE,
        ALTER,
        CREATE,
        UNK
    }

    public QueryType getType() {
        return type;
    }

    public Tool8File getInFile() {
        return inFile;
    }

    public String getOrgQuery() {
        return orgQuery;
    }

    public String getTransQuery1() {
        return transQuery1;
    }

    public String getTransQuery2() {
        return transQuery2;
    }

    public String getTransQuery3() {
        return transQuery3;
    }

    private QueryType type;
    private Tool8File inFile;
    private String orgQuery;
    private String transQuery1;      // query with no line break, and trimmed left and right.
    private String transQuery2;  // transQuery1 with no consecutive space. This might affect string values in ' ' in query.
    private String transQuery3;  // same with 2, but from and join is in a new line.

    public static final List<String> insertPrefix = Arrays.asList("INSERT INTO TABLE", "INSERT INTO", "INSERT OVERWRITE TABLE");
    public static final List<String> deletePrefix = Arrays.asList("drop table if exists", "DROP TABLE", "DELETE FROM");
    public static final List<String> createPrefix = Arrays.asList("CREATE EXTERNAL TABLE IF NOT EXISTS", "CREATE TABLE IF NOT EXISTS", "CREATE EXTERNAL TABLE", "CREATE TABLE");
    public static final List<String> updatePrefix = Arrays.asList("UPDATE");
    public static final List<String> alterPrefix = Arrays.asList("ALTER TABLE");
    public static final List<String> selectPrefix = Arrays.asList("SELECT");

    private String transformingQuery1(String query){
        String result = StringUtils.replace(query, "\r\n", " ");
        result = StringUtils.trim(result);
        return result;
    }

    private String transformingQuery2(String query){
        String result = transformingQuery1(query);
        result = StringUtils.normalizeSpace(result);
        return result;
    }

    private String transformingQuery3(String query){
        String result = transformingQuery2(query);
        result = result.replaceAll("from", "\r\n\tfrom");
        result = result.replaceAll("join", "\r\n\tjoin");
        return result;
    }


    public Tool8Query(Tool8File inFile, String query) {
        this.inFile = inFile;
        this.orgQuery = query;
        this.transQuery1 = transformingQuery1(query);
        this.transQuery2 = transformingQuery2(query);
        this.transQuery3 = transformingQuery3(query);
        if (GeneralUtils.startsWithAnyIgnoreCase(transQuery1, insertPrefix)){
            this.type = QueryType.INSERT;
        }else if (GeneralUtils.startsWithAnyIgnoreCase(transQuery1, updatePrefix)){
            this.type = QueryType.UPDATE;
        }else if (GeneralUtils.startsWithAnyIgnoreCase(transQuery1, selectPrefix)){
            this.type = QueryType.SELECT;
        }else if (GeneralUtils.startsWithAnyIgnoreCase(transQuery1, deletePrefix)){
            this.type = QueryType.DELETE;
        }else if (GeneralUtils.startsWithAnyIgnoreCase(transQuery1, alterPrefix)){
            this.type = QueryType.ALTER;
        }else if (GeneralUtils.startsWithAnyIgnoreCase(transQuery1, createPrefix)){
            this.type = QueryType.CREATE;
        }else{
            this.type = QueryType.UNK;
        }
    }
}
