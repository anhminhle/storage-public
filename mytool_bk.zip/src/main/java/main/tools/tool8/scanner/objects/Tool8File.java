/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool8.scanner.objects;

import java.nio.file.Paths;

/**
 *
 * @author minhla2
 */
public class Tool8File {
    private String absolutePath;
    private String content;

    public String getFileName() {
        return Paths.get(absolutePath).getFileName().toString();
    }

    public String getAbsolutePath() {
        return absolutePath;
    }

    public void setAbsolutePath(String absolutePath) {
        this.absolutePath = absolutePath;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Tool8File(String absolutePath, String content) {
        this.absolutePath = absolutePath;
        this.content = content; 
    }
}
