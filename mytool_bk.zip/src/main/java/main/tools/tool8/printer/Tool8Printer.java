/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool8.printer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Queue;
import main.tools.tool8.scanner.objects.Tool8Graph;
import main.tools.tool8.scanner.objects.Tool8Query;
import main.tools.tool8.scanner.objects.Tool8Table;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
public class Tool8Printer {

    private Tool8Graph tool8Graph;
    private String outDir;  // outDir has '/' at the end

    public Tool8Printer(Tool8Graph tool8Graph, String outDir) {
        this.tool8Graph = tool8Graph;
        this.outDir = outDir;
    }

    private LinkedHashMap<String, Integer> depthBFS(String tableName){
        LinkedHashMap<String, Integer> bfsDepth = new LinkedHashMap<>();
        Queue<String> bfsQueue = new ArrayDeque<>();
        bfsQueue.add(tableName);
        bfsDepth.put(tableName, 0);
        while (!bfsQueue.isEmpty()){
            String currTableName = bfsQueue.poll();
            for (String parTableName : tool8Graph.getGraph().get(currTableName).getParentTableNames()){
                if (!bfsDepth.containsKey(parTableName)){
                    bfsQueue.add(parTableName);
                    bfsDepth.put(parTableName, bfsDepth.get(currTableName) + 1);
                }
            }
        }
        return bfsDepth;
    }

    public void printTable(String tableName) throws IOException{
        String tableOutDir = outDir + tableName + "/";
        Files.createDirectories(Paths.get(tableOutDir));
        Tool8Table tool8Table = tool8Graph.getGraph().get(tableName);
        if (tool8Table != null){
            printTableGraph(tableName, tableOutDir);
            printTableInfo(tableName, tableOutDir);
        }
    }


    public void printTableGraph(String tableName, String tableOutDir) throws IOException{
        String graphFileNamePath = tableOutDir + "graph_" + tableName + ".txt";
        GeneralUtils.deleteFileIfExists(graphFileNamePath);
        LinkedHashMap<String, Integer> bfsDepth = depthBFS(tableName);
        for (String table : bfsDepth.keySet()){
            Integer tableDepth = bfsDepth.get(table);
            String outString = "";

            for (int i=0;i<tableDepth;i++) outString = outString + "\t";
            outString = outString + tableDepth + "." + table + ": ";

            for (String parTable : tool8Graph.getGraph().get(table).getParentTableNames()){
                outString = outString + parTable + ", ";
            }
            GeneralUtils.dumpStringsToFile(Arrays.asList(outString), graphFileNamePath, true);
        }
    }
    public void printTableInfo(String tableName, String tableOutDir) throws IOException{
        Tool8Table tool8Table = tool8Graph.getGraph().get(tableName);
        String fileNamePath = tableOutDir + tableName + ".sql";

        GeneralUtils.deleteFileIfExists(fileNamePath);
        GeneralUtils.dumpStringsToFile(new ArrayList<>(tool8Table.getParentTableNames()),
                fileNamePath, true);
        for (Tool8Query tool8Query : tool8Table.getQueries()){
            GeneralUtils.dumpStringsToFile(Arrays.asList(tool8Query.getInFile().getAbsolutePath()),
                fileNamePath, true);
            GeneralUtils.dumpStringsToFile(Arrays.asList(tool8Query.getTransQuery3()),
                fileNamePath, true);
        }
    }
}
