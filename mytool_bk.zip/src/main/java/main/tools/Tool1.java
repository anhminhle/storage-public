/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools;

import constants.Constants;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 *
 * @author minhla2
 * FindQueryTexts
 */
public class Tool1{
    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool1/";
    final String CONFIG_DIR = TOOL_DIR + "configTool1.properties";
    final String FOLDER_IN_DIR = TOOL_DIR + "Files/In";
    final String FOLDER_OUT_DIR = TOOL_DIR + "Files/out";
    String folderIn;
    String folderOut;
//    String defaultFileNameIn;
    Boolean isSeperatingFiles;
    
    public Tool1(){
    }
    
    private void init() throws IOException{
        
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            // get the property value and print it out
            folderIn = FOLDER_IN_DIR;
            folderOut = FOLDER_OUT_DIR;
            isSeperatingFiles = prop.get("isSeperatingFiles").equals("1");
            
            Files.createDirectories(Paths.get(folderIn));
            Files.createDirectories(Paths.get(folderOut));
        }
    }
    
//    public void findInFile(String str, String filePathIn, String filePathOut) throws FileNotFoundException, IOException{
//        try(
//                FileReader reader = new FileReader(filePathIn); 
//                FileWriter writer = new FileWriter(filePathOut);
//                BufferedReader bufferedReader = new BufferedReader(reader);
//                BufferedWriter bufferedWriter = new BufferedWriter(writer);
//            ){
//            String line;
//            int lineNo = 0;
//            while ((line = bufferedReader.readLine()) != null){
//                lineNo++;
//                if (line.contains(str)){
//                    bufferedWriter.write("Line " + lineNo + ": " + line);
//                    bufferedWriter.newLine();
//                }
//            }
//        };
//    }
    
    public void findInFile(String filePathIn, String filePathOut) throws IOException{
        try(
                FileReader reader = new FileReader(filePathIn); 
                FileWriter writer = new FileWriter(filePathOut, true);
                BufferedReader bufferedReader = new BufferedReader(reader);
                BufferedWriter bufferedWriter = new BufferedWriter(writer);
            ){
            String line;
            // int lineNo = 0;
            boolean queryText = false;
            bufferedWriter.write(filePathIn);
            bufferedWriter.newLine();
            while ((line = bufferedReader.readLine()) != null){
                // lineNo++;
                if (line.contains("queryText")) queryText = true;
                if (queryText)
                {
                    bufferedWriter.write(line);
                    bufferedWriter.newLine();
                }
                if (queryText && line.contains("</xml-property>")){
                    queryText = false;
                    bufferedWriter.newLine();
                }
            }
        }
    }
       
    public void main() throws IOException{
        init();
        findInFolder(folderIn);
    }
        
    public void findInFolder(String folderPathIn) throws IOException{
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(folderPathIn))) {
            for (Path path : stream) {
                if (!Files.isDirectory(path)) {
                    String filePathIn = path.toString();
                    String fileNameOut; 
                    fileNameOut = (isSeperatingFiles ? path.getFileName().toString().replaceFirst("[.][^.]+$", "") 
                            : "out") + ".xml";
                    String filePathOut = this.folderOut + "/" + fileNameOut;
                    findInFile(filePathIn, filePathOut);
                    System.out.println("Xong file: " + filePathIn);
                }
            }
        }
    }
}
