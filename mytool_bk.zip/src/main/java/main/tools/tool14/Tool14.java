/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.tools.tool14;

import constants.Constants;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import utils.GeneralUtils;
import utils.docutils.DocUtils;

/**
 *
 * @author minhla2
 * replace a string in a .docx file (.doc might work).
 */
public class Tool14 {
    private static final Logger logger = Logger.getLogger(Tool14.class);
    // private static final Logger consoleLogger = Logger.getLogger("CONSOLE");

    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool14/";
    final String CONFIG_DIR = TOOL_DIR + "configTool14.properties";
    final String FOLDER_IN_DIR = TOOL_DIR + "In/";
    final String FOLDER_IN_MSWORD_FILES_DIR = FOLDER_IN_DIR + "MSWordFiles/";
    final String FOLDER_OUT_DIR = TOOL_DIR + "Out/";
    final String STRINGS_DIR = FOLDER_IN_DIR + "Strings.txt";
    List<String> stringsList;
    Map<String, String> stringsMap;

    public void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(FOLDER_IN_DIR));
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        Files.createDirectories(Paths.get(FOLDER_IN_MSWORD_FILES_DIR));
        GeneralUtils.createFileIfNotExists(CONFIG_DIR);
        GeneralUtils.createFileIfNotExists(STRINGS_DIR);
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            String stringsText = new String(Files.readAllBytes(Paths.get(STRINGS_DIR)), "UTF-8");
            stringsList = Arrays.asList(stringsText.replaceAll("\r", "").split("\n"));
            stringsMap = new HashMap<>();
            for (int i=0;i<stringsList.size();i+=2){
                stringsMap.put(stringsList.get(i), stringsList.get(i+1));
            }
        }
    }

    public void tool14ExecuteFile(String filePathIn, String filePathOut) throws IOException{
        try(
            FileInputStream fInput = new FileInputStream(filePathIn);
            FileOutputStream out = new FileOutputStream(filePathOut);)
        {
            XWPFDocument doc = new XWPFDocument(fInput);
            DocUtils.replaceDocx(doc, stringsMap);
            doc.write(out);
        }
    }
    public void tool14ExecuteFolderIn(String folderPathIn) throws IOException{
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(folderPathIn))) {
            for (Path path : stream) {
                if (!Files.isDirectory(path)) {
                    String filePathIn = path.toString();
                    String fileNameOut;
                    fileNameOut = path.getFileName().toString();
                    String filePathOut = this.FOLDER_OUT_DIR + fileNameOut;
                    System.out.println("Execute file: " + filePathIn);
                    tool14ExecuteFile(filePathIn, filePathOut);
                    System.out.println("Xong file: " + filePathIn);
                }
            }
        }
    }
    public void main() throws IOException, ClassNotFoundException, SQLException{
        init();
        logger.info("Tool 14 Start!");
        System.out.println("Tool 14 Start!");
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        tool14ExecuteFolderIn(FOLDER_IN_MSWORD_FILES_DIR);
//        FunctionUtils.deleteFileIfExists(OUT_ENCRYPTED_DIR);
//        FunctionUtils.createFileIfNotExists(OUT_ENCRYPTED_DIR);
//        FunctionUtils.deleteFileIfExists(OUT_DECRYPTED_DIR);
//        FunctionUtils.createFileIfNotExists(OUT_DECRYPTED_DIR);

        logger.info("Tool 14 Complete!");
        System.out.println("Tool 14 Complete!");
    }
}
