package main.tools;
public class Tool5{}
/*
import constants.Constants;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.birt.core.exception.BirtException;
import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.report.engine.api.EngineConfig;
import org.eclipse.birt.report.engine.api.EngineException;
import org.eclipse.birt.report.engine.api.IRenderTask;
import org.eclipse.birt.report.engine.api.IReportDocument;
import org.eclipse.birt.report.engine.api.IReportEngine;
import org.eclipse.birt.report.engine.api.IReportEngineFactory;
import org.eclipse.birt.report.engine.api.IReportRunnable;
import org.eclipse.birt.report.engine.api.IRunTask;
import org.eclipse.birt.report.engine.api.PDFRenderOption;


// birtToPdf
public class Tool5{
    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool5/";
    final String CONFIG_DIR = TOOL_DIR + "configTool5.properties";
    final String OUT_DIR = TOOL_DIR + "Out/";
    final String IN_DIR = TOOL_DIR + "In/";
    final String REPORT_DESIGN_DIR = IN_DIR + "design/";
    final String OUT_DOC_DIR = OUT_DIR + "doc/";
    final String OUT_PDF_DIR = OUT_DIR + "pdf/";
    final String BIRT_LIB_PATH = "lib"; //TODO: set this.
    String prdId;
    String folderInPath;
    Boolean isSeperatingFiles;
    List<String> listStrings;
    static IReportEngine engine = null;
    EngineConfig config = null;

    private void startBirtPlatform(){
        try {
            // Configure the Engine and start the Platform
            config = new EngineConfig();
            config.setEngineHome(BIRT_LIB_PATH);

            Platform.startup(config);
            final IReportEngineFactory FACTORY = (IReportEngineFactory) Platform.
                    createFactoryObject(IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY);

            engine = FACTORY.createReportEngine(config);
            engine.changeLogLevel(Level.WARNING);
            Logger.getLogger(Tool5.class.getName()).log(Level.INFO, "Start Birt Platform thanh cong");
        } catch (BirtException ex) {
            Logger.getLogger(Tool5.class.getName()).log(Level.SEVERE, "Tool 5: Start Birt Platform khong thanh cong", ex);
        }
    }
    private void init() throws IOException, BirtException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(IN_DIR));
        Files.createDirectories(Paths.get(OUT_DIR));
        Files.createDirectories(Paths.get(REPORT_DESIGN_DIR));
        Files.createDirectories(Paths.get(OUT_DOC_DIR));
        Files.createDirectories(Paths.get(OUT_PDF_DIR));
        try{
            Files.createFile(Paths.get(CONFIG_DIR));
        }catch (FileAlreadyExistsException ex){
            // do nothing
        }
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            prdId = prop.getProperty("prdId");
        }
        startBirtPlatform();
    }

    public Tool5(){
    }

    public void executeBirtPdf(String reportDesignPath, String rptdocPath, String pdfResultPath, String birtLibPath, String prdId) throws ParseException, BirtException{
        final HashMap<String, java.sql.Date> PARAMETERS = new HashMap<String, java.sql.Date>();
        final String NAME = "from_date";
        Date d = new SimpleDateFormat("yyyyMMdd").parse("20221024");
        Calendar c = Calendar.getInstance();
        c.setTime(d);
        java.sql.Date sq = new java.sql.Date(c.getTime().getTime());
        PARAMETERS.put(NAME, sq);
        executeBirtPdf(this.engine, PARAMETERS, reportDesignPath, rptdocPath, pdfResultPath);
    }

    public void executeBirtPdf(String reportDesignPath, String rptdocPath, String pdfResultPath, String birtLibPath, String prdId, String provinceCode) throws ParseException, BirtException{
        final HashMap<String, Object> PARAMETERS = new HashMap<>();
        final String NAME = "from_date";
        Date d = new SimpleDateFormat("yyyyMMdd").parse("20221024");
        Calendar c = Calendar.getInstance();
        c.setTime(d);
        java.sql.Date sq = new java.sql.Date(c.getTime().getTime());
        PARAMETERS.put(NAME, sq);
        PARAMETERS.put("province_code", provinceCode);
        executeBirtPdf(this.engine, PARAMETERS, reportDesignPath, rptdocPath, pdfResultPath);
    }

    public void executeBirtPdf(String reportDesignPath, String rptdocPath, String pdfResultPath, String birtLibPath, Map PARAMETERS) throws ParseException, BirtException{
        executeBirtPdf(this.engine, PARAMETERS, reportDesignPath, rptdocPath, pdfResultPath);
    }

    public void executeBirtInFolder(String folderPathIn) throws IOException, ParseException, BirtException{
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(folderPathIn))) {
            for (Path path : stream) {
                if (!Files.isDirectory(path)) {
                    String fileDesignPathIn = path.toString();
                    if (!fileDesignPathIn.endsWith(".rptdesign")) continue;
                    String fileNameOut;
                    fileNameOut = path.getFileName().toString().replaceFirst("[.][^.]+$", "") ;
                    String fileDocPathOut = OUT_DOC_DIR + fileNameOut + ".rptdocument";
                    String filePdfPathOut = OUT_PDF_DIR + fileNameOut + ".pdf";
                    Logger.getLogger(Tool5.class.getName()).log(Level.INFO, "Den {0}", fileDesignPathIn);

//                    executeBirtPdf(fileDesignPathIn, fileDocPathOut, filePdfPathOut, BIRT_LIB_PATH, prdId, "HNI");
                    executeBirtPdf(fileDesignPathIn, fileDocPathOut, filePdfPathOut, BIRT_LIB_PATH, prdId);
                    Logger.getLogger(Tool5.class.getName()).log(Level.INFO, "Xong {0}", fileDesignPathIn);
                }
            }
        }
    }
    public void main() throws ClassNotFoundException, SQLException, IOException, ParseException, BirtException{
        init();
        executeBirtInFolder(REPORT_DESIGN_DIR);
    }

    //Execute birt file ra Pdf
    private static void executeBirtPdf(IReportEngine engine, Map PARAMETERS, String reportDesignPath,
        String rptdocPath, String pdfResultPath) throws EngineException{
//      //   Open the report design
        IRunTask task = null;
        IReportDocument iReportDoc = null;
        IRenderTask renderTask = null;
        try {
            final IReportRunnable DESIGN
                    = engine.openReportDesign(reportDesignPath);

//         Create task to run and render the report:
//
            task = engine.createRunTask(DESIGN);
            task.setParameterValues(PARAMETERS);
            task.validateParameters();
//
//            //Create rptdocument
            task.run(rptdocPath);

            iReportDoc = engine.openReportDocument(rptdocPath);
            renderTask = engine.createRenderTask(iReportDoc);
            PDFRenderOption options = new PDFRenderOption();
            options.setOutputFormat("pdf");
            //options.setOutputStream("");
            options.setOutputFileName(pdfResultPath);//duong dan ten file
            renderTask.setRenderOption(options);
            renderTask.render();
        } finally {
            if (renderTask != null) {
                renderTask.close();
            }
            if (iReportDoc != null) {
                iReportDoc.close();
            }
            if (task != null) {
                task.close();
            }
        }
    }
}
*/