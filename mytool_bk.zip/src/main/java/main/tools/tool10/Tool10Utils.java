/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool10;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
public class Tool10Utils {

    //Use https. Source: https://stackoverflow.com/questions/18576069/how-to-save-the-file-from-https-url-in-java
    static {
        final TrustManager[] trustAllCertificates = new TrustManager[] {
            new X509TrustManager() {
                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return null; // Not relevant.
                }
                @Override
                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    // Do nothing. Just allow them all.
                }
                @Override
                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    // Do nothing. Just allow them all.
                }
            }
        };

        try {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCertificates, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (GeneralSecurityException e) {
            throw new ExceptionInInitializerError(e);
        }
    }
    public static void urlToHTMLText(String url, String filePathOut) throws IOException{
        GeneralUtils.deleteFileIfExists(filePathOut);
        GeneralUtils.createFileIfNotExists(filePathOut);
        java.net.URL website = new java.net.URL(url);

        try (
            ReadableByteChannel channel = Channels.newChannel(website.openStream());
            FileOutputStream stream = new FileOutputStream(filePathOut);
                )
        {
            stream.getChannel().transferFrom(channel, 0, Long.MAX_VALUE);
            System.out.println("Download successful. " + url);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Download was not successful. " + url);
        }
    }

    public static void urlToHTMLText(String url, String filePathOut, String login, String password) throws IOException{
        Authenticator.setDefault(new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(login, password.toCharArray());
            }
        });
        urlToHTMLText(url, filePathOut);
    }
    /*
    // url output to a file with filePathOut, and htmlOutput stored
    public static void urlToHTMLText(String url, String filePathOut, String htmlOutput) throws IOException{
        FunctionUtils.deleteFileIfExists(filePathOut);
        FunctionUtils.createFileIfNotExists(filePathOut);
        java.net.URL website = new java.net.URL(url);
        try (
            ReadableByteChannel channel = Channels.newChannel(website.openStream());
            FileOutputStream stream = new FileOutputStream(filePathOut);
                )
        {
            stream.getChannel().transferFrom(channel, 0, Long.MAX_VALUE);
            htmlOutput = new String(Files.readAllBytes(Paths.get(filePathOut)), "UTF-8");
            System.out.println("Download successful. " + url);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Download was not successful. " + url);
        }
    }

    public static void urlToHTMLText(String url, String filePathOut, String login, String password, String htmlOutput) throws IOException{
        Authenticator.setDefault(new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(login, password.toCharArray());
            }
        });
        urlToHTMLText(url, filePathOut, htmlOutput);
    }    */

}
