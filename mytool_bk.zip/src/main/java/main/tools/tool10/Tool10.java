/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool10;

import constants.Constants;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
public class Tool10{
    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool10/";
    final String CONFIG_DIR = TOOL_DIR + "configTool10.properties";
    final String FOLDER_IN_DIR = TOOL_DIR + "In/";
    final String FOLDER_OUT_DIR = TOOL_DIR + "Out/";
    final String URL_IN_FILE = FOLDER_IN_DIR + "url.txt";
    final String STRINGS_TO_FIND_FILE = FOLDER_IN_DIR + "stringsToFind.txt";
    Boolean doAuthenticate;
    String username;
    String password;
    List<String> inUrls;
    List<String> stringsToFind;

    public void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(FOLDER_IN_DIR));
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        GeneralUtils.createFileIfNotExists(CONFIG_DIR);
        GeneralUtils.createFileIfNotExists(URL_IN_FILE);
        GeneralUtils.createFileIfNotExists(STRINGS_TO_FIND_FILE);
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {
            Properties prop = new Properties();
            // load a properties file
            prop.load(input);
            doAuthenticate = prop.get("doAuthenticate").equals("1");
            username = prop.getProperty("username");
            password = prop.getProperty("password");
        }
        String textInUrls = new String(Files.readAllBytes(Paths.get(URL_IN_FILE)), "UTF-8");
        inUrls = Arrays.asList(textInUrls.replaceAll("\r", "").split("\n"));
        String textStringsToFind = new String(Files.readAllBytes(Paths.get(STRINGS_TO_FIND_FILE)), "UTF-8");
        stringsToFind = Arrays.asList(textStringsToFind.replaceAll("\r", "").split("\n"));
    }


    // find string in folder filePathIn then out to filePathOut
    public void tool9FindString(String stringToFind, String filePathIn, String filePathOut) throws IOException{
        String textIn = new String(Files.readAllBytes(Paths.get(filePathIn)), "UTF-8");
        int startPos = 0;
        int range = 300;
        try(
            FileWriter writer = new FileWriter(filePathOut);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
        ){
            while ((startPos = (textIn.indexOf(stringToFind, startPos))) != -1){
                int begin = startPos - range >= 0 ? startPos - range : 0;
                int end = startPos + range < textIn.length() ? startPos + range : textIn.length();
                String findText = textIn.substring(begin, end);
                bufferedWriter.write(findText);
                bufferedWriter.newLine();
                bufferedWriter.newLine();
                startPos = end - stringToFind.length();
            }
        }
    }

    public void appendToFile(String text, String filePathOut) throws IOException{
        try(
            FileWriter writer = new FileWriter(filePathOut, true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
        ){
            bufferedWriter.write(text);
        }
    }

    public void main() throws IOException{
        init();
        String filePathOutFull = FOLDER_OUT_DIR + "out_full/";
        Files.createDirectories(Paths.get(filePathOutFull));
        Map<String, String> urlHTMLContentMap = new TreeMap<>();  // key: url (ip:port only), value: html content
        for (int i=0;i<inUrls.size();i++){
            String filePathOut = filePathOutFull + "out" + i + ".html";
            String slaveStatusUrl = "https://"+ inUrls.get(i) + "/kettle/status/";
            String htmlOutput = "";
            if (doAuthenticate) {
                Tool10Utils.urlToHTMLText(slaveStatusUrl, filePathOut, username, password);
            }else{
                Tool10Utils.urlToHTMLText(slaveStatusUrl, filePathOut);
            }
            htmlOutput = new String(Files.readAllBytes(Paths.get(filePathOut)), "UTF-8");
            urlHTMLContentMap.put(inUrls.get(i), htmlOutput);
        }
        String filePathOutHyperLinksFull = filePathOutFull + "out_hyperlinks_full.html";
        GeneralUtils.deleteFileIfExists(filePathOutHyperLinksFull);
        GeneralUtils.createFileIfNotExists(filePathOutHyperLinksFull);
        Map<String, String> hyperLinksUrlMap = new TreeMap<>(); //key: hyperLink, value: kettleHyperLink
        for (int stringNo=0;stringNo<stringsToFind.size();stringNo++){
            String stringToFind = stringsToFind.get(stringNo);
            System.out.println("String: " + stringToFind);
//            String filePathOutHyperLinks = filePathOutFull + "out_hyperlinks_" + stringNo + ".html";
//            FunctionUtils.deleteFileIfExists(filePathOutHyperLinks);
//            FunctionUtils.createFileIfNotExists(filePathOutHyperLinks);
            for (int i=0;i<inUrls.size();i++){
                String htmlContent = urlHTMLContentMap.get(inUrls.get(i));
                List<String> hyperLinks = GeneralUtils.extractAllHyperLink(htmlContent);
                String beforeSubStr = "/kettle";
                for (String hyperLink : hyperLinks){
                    Integer idx = hyperLink.indexOf(beforeSubStr);
                    if (hyperLink.contains(stringToFind) && idx !=-1){
                        String kettleHyperLink = GeneralUtils.insertStringBeforeIndex(hyperLink, "https://" + inUrls.get(i), idx-1);
                        hyperLinksUrlMap.put(hyperLink, kettleHyperLink);
//                        appendToFile(kettleHyperLink + "\r\n" + inUrls.get(i) + "<br>", filePathOutHyperLinks);
                    }
                }
            }
        }
        for (Map.Entry<String, String>
                 entry : hyperLinksUrlMap.entrySet()){
            // final String hyperLink = entry.getKey();
            String kettleHyperLink = entry.getValue();
            appendToFile(kettleHyperLink + "\r\n<br>", filePathOutHyperLinksFull);
        }
    }
}
