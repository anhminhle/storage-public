/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools.tool10;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 */
public class Tool10_BK {
    final String TOOL_DIR = "tools/tool10/";
    final String CONFIG_DIR = TOOL_DIR + "configTool10.properties";
    final String FOLDER_IN_DIR = TOOL_DIR + "In/";
    final String FOLDER_OUT_DIR = TOOL_DIR + "Out/";
    final String URL_IN_FILE = FOLDER_IN_DIR + "url.txt";
    final String STRINGS_TO_FIND_FILE = FOLDER_IN_DIR + "stringsToFind.txt";
    Boolean doAuthenticate;
    String username;
    String password;
    List<String> inUrls;
    List<String> stringsToFind;

    public void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(FOLDER_IN_DIR));
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        GeneralUtils.createFileIfNotExists(CONFIG_DIR);
        GeneralUtils.createFileIfNotExists(URL_IN_FILE);
        GeneralUtils.createFileIfNotExists(STRINGS_TO_FIND_FILE);
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {
            Properties prop = new Properties();
            // load a properties file
            prop.load(input);
            doAuthenticate = prop.get("doAuthenticate").equals("1");
            username = prop.getProperty("username");
            password = prop.getProperty("password");
        }
        String textInUrls = new String(Files.readAllBytes(Paths.get(URL_IN_FILE)), "UTF-8");
        inUrls = Arrays.asList(textInUrls.replaceAll("\r", "").split("\n"));
        String textStringsToFind = new String(Files.readAllBytes(Paths.get(STRINGS_TO_FIND_FILE)), "UTF-8");
        stringsToFind = Arrays.asList(textStringsToFind.replaceAll("\r", "").split("\n"));
    }

    public void urlToHTMLText(String url, String filePathOut) throws IOException{
        GeneralUtils.deleteFileIfExists(filePathOut);
        GeneralUtils.createFileIfNotExists(filePathOut);
        java.net.URL website = new java.net.URL(url);
        try (
            ReadableByteChannel channel = Channels.newChannel(website.openStream());
            FileOutputStream stream = new FileOutputStream(filePathOut);
                )
        {
            stream.getChannel().transferFrom(channel, 0, Long.MAX_VALUE);
            System.out.println("Download successful. " + url);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Download was not successful. " + url);
        }
    }

    public void urlToHTMLText(String url, String filePathOut, String login, String password) throws IOException{
        Authenticator.setDefault(new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(login, password.toCharArray());
            }
        });
        urlToHTMLText(url, filePathOut);
    }

    // find string in folder filePathIn then out to filePathOut
    public void tool9FindString(String stringToFind, String filePathIn, String filePathOut) throws IOException{
        String textIn = new String(Files.readAllBytes(Paths.get(filePathIn)), "UTF-8");
        int startPos = 0;
        int range = 300;
        try(
            FileWriter writer = new FileWriter(filePathOut);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
        ){
            while ((startPos = (textIn.indexOf(stringToFind, startPos))) != -1){
                int begin = startPos - range >= 0 ? startPos - range : 0;
                int end = startPos + range < textIn.length() ? startPos + range : textIn.length();
                String findText = textIn.substring(begin, end);
                bufferedWriter.write(findText);
                bufferedWriter.newLine();
                bufferedWriter.newLine();
                startPos = end - stringToFind.length();
            }
        }
    }

    public void appendToFile(String text, String filePathOut) throws IOException{
        try(
            FileWriter writer = new FileWriter(filePathOut, true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
        ){
            bufferedWriter.write(text);
        }
    }

    public void main() throws IOException{
        init();
        for (int stringNo=0;stringNo<stringsToFind.size();stringNo++){
            String stringToFind = stringsToFind.get(stringNo);
            System.out.println("String: " + stringToFind);
            String curFolderOutDir = FOLDER_OUT_DIR + stringNo + "/";
            Files.createDirectories(Paths.get(curFolderOutDir));
            String filePathOutHyperLinksOneFile = curFolderOutDir + "out_hyperlinks.html";
            GeneralUtils.deleteFileIfExists(filePathOutHyperLinksOneFile);
            GeneralUtils.createFileIfNotExists(filePathOutHyperLinksOneFile);
            for (int i=0;i<inUrls.size();i++){
                String filePathOut = curFolderOutDir + "out" + i + ".html";
                String slaveUrl = "http://"+ inUrls.get(i) + "/kettle/status/";
                if (doAuthenticate) {
                    urlToHTMLText(slaveUrl, filePathOut, username, password);
                }else{
                    urlToHTMLText(slaveUrl, filePathOut);
                }
                String filePathOutHyperLinks = curFolderOutDir + "out_hyperlinks" + i + ".html";
                List<String> hyperLinks = GeneralUtils.extractAllHyperLink(filePathOut);
                String beforeSubStr = "/kettle";
                GeneralUtils.deleteFileIfExists(filePathOutHyperLinks);
                GeneralUtils.createFileIfNotExists(filePathOutHyperLinks);
                for (String hyperLink : hyperLinks){
                    Integer idx = hyperLink.indexOf(beforeSubStr);
                    if (hyperLink.contains(stringToFind) && idx !=-1){
                        String kettleHyperLink = GeneralUtils.insertStringBeforeIndex(hyperLink, "http://" + inUrls.get(i), idx-1);
                        appendToFile(kettleHyperLink + "\r\n<br>", filePathOutHyperLinks);
                        appendToFile(kettleHyperLink + "\r\n<br>", filePathOutHyperLinksOneFile);
                    }
                }
            }
        }

    }
}
