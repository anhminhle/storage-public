/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package main.tools;

import constants.Constants;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;
import javax.imageio.ImageIO;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;

/**
 *
 * @author minhla2
 * pdfToImg
 */
public class Tool6{
    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool6/";
    final String CONFIG_DIR = TOOL_DIR + "configTool6.properties";
    final String OUT_DIR = TOOL_DIR + "Out";
    Integer dpi;
    String fileInPath;
    
    private void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(OUT_DIR));
        try{
            Files.createFile(Paths.get(CONFIG_DIR));
        }catch (FileAlreadyExistsException ex){
            // do nothing
        }
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            // get the property value and print it out
            fileInPath = prop.getProperty("fileInPath");
            dpi = Integer.parseInt(prop.getProperty("dpi"));
        }
    }
    
    public static int convertPdfToImg(String sourFile, String desFile, int dpi) {
        int numOfImages = 0;
        try {
            String sourceDir = sourFile; // Pdf files are read from this folder
            String destinationDir = desFile; // converted images from pdf document are saved here

            File sourceFile = new File(sourceDir);
            File destinationFile = new File(destinationDir);
            if (!destinationFile.exists()) {
                destinationFile.mkdir();
                System.out.println("Folder Created -> " + destinationFile.getAbsolutePath());
            }
            if (sourceFile.exists()) {
                System.out.println("Images copied to Folder Location: " + destinationFile.getAbsolutePath());
                PDDocument document = PDDocument.load(sourceFile);
                PDFRenderer pdfRenderer = new PDFRenderer(document);

                int numberOfPages = document.getNumberOfPages();
                System.out.println("Total files to be converting -> " + numberOfPages);

                String fileName = sourceFile.getName().replace(".pdf", "");
                String fileExtension = "png";

                for (int i = 0; i < numberOfPages; ++i) {
                    File outPutFile = new File(destinationDir + fileName + "_" + (i + 1) + "." + fileExtension);
                    BufferedImage bImage = pdfRenderer.renderImageWithDPI(i, dpi, ImageType.RGB);
                    ImageIO.write(bImage, fileExtension, outPutFile);
                    numOfImages++;
                }

                document.close();
                System.out.println("Converted Images are saved at -> " + destinationFile.getAbsolutePath());
            } else {
                System.err.println(sourceFile.getName() + " File not exists");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return numOfImages;
    }
    
    public Tool6(){
    }
    
    public void main() throws IOException{
        init();
        convertPdfToImg(fileInPath, OUT_DIR + "\\", dpi);
    }
}

