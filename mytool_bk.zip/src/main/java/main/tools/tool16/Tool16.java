/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.tools.tool16;

import constants.Constants;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Logger;

import com.google.gson.Gson;
import utils.GeneralUtils;

/**
 *
 * @author minhla2
 * Extract from a json file
 */
public class Tool16 {
    private static final Logger logger = Logger.getLogger(Tool16.class);
    // private static final Logger consoleLogger = Logger.getLogger("CONSOLE");

    final String TOOL_DIR = Constants.COMMON_TOOLS_DIR + "tool16/";
    final String CONFIG_DIR = TOOL_DIR + "configTool16.properties";
    final String FOLDER_IN_DIR = TOOL_DIR + "In/";
    final String FOLDER_OUT_DIR = TOOL_DIR + "Out/";
    final String JSON_DIR = FOLDER_IN_DIR + "json.txt";
    final String OUT_DIR = FOLDER_OUT_DIR + "out.txt";
    List<String> listTelsAccepted;
    List<String> listTels;
    List<String> stringsList;
    String stringText;

    public void init() throws IOException{
        Files.createDirectories(Paths.get(TOOL_DIR));
        Files.createDirectories(Paths.get(FOLDER_IN_DIR));
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));
        GeneralUtils.createFileIfNotExists(CONFIG_DIR);
        GeneralUtils.createFileIfNotExists(JSON_DIR);
        try (InputStream input = new FileInputStream(CONFIG_DIR)) {

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);
        }
    }
    public void main() throws IOException, ClassNotFoundException, SQLException{
        init();
        logger.info("Tool 16 Start!");
        System.out.println("Tool 16 Start!");
        Files.createDirectories(Paths.get(FOLDER_OUT_DIR));

        try(
            BufferedReader inReader = new BufferedReader(new FileReader(JSON_DIR));
            BufferedReader outReader = new BufferedReader(new FileReader(JSON_DIR))
            ;)
        {
            Gson gson = new Gson();
            Map jsonIn = gson.fromJson(inReader, Map.class);
            GeneralUtils.appendToFile(jsonIn.toString(), OUT_DIR, true);
        }

        logger.info("Tool 16 Complete!");
        System.out.println("Tool 16 Complete!");
    }
}
