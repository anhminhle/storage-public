/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package constants;

/**
 *
 * @author minhla2
 */
public class Constants {
    public static final String COMMON_TOOLS_DIR = "tools/";
    public static final char[] WINDOWS_FILE_NAME_SAFE_CHARACTERS = {'\\','/',':','*','?','"','<','>','?'};
}
